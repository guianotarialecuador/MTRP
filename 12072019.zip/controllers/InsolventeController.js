const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico


module.exports = (app,User,Insolvente) => {
    
    app.get('/api/insolventes', verificarToken(User),(req,res) => {
        Insolvente.find({},function(err,insolventes){
            if (err)
                res.send(err);

            res.json(insolventes);
        });
    });

    app.get('/api/insolventes-nombre/:nombre', verificarToken(User),(req,res) => {
        Insolvente.find({nombre: req.params.nombre},function(err,insolventes){
            if (err)
                res.send(err);

            res.json(insolventes);
        });
    });

    app.get('/api/insolventes-cedula/:cedula', verificarToken(User),(req,res) => {
        Insolvente.find({cedula: req.params.cedula},function(err,insolventes){
            if (err)
                res.send(err);

            res.json(insolventes);
        });
    });


    app.delete('/api/insolventes/:id',verificarToken(User),(req,res)=>{
        Insolvente.findById(req.params.id,function(err,insolvente) {
            if (err)
                res.send(err);
            
            if (insolvente) {
                Insolvente.findByIdAndDelete(req.params.id,function(e){
                    if (e)
                        res.send(e);
                    res.json({
                        msg_servidor_success: 'Insolvente Eliminado.'
                    });
                });         
            }else{
                res.json({
                    msg_servidor: 'Esa Persona no Existe.'
                });
            }

        });
    });

    app.post('/api/insolventes',verificarToken(User),(req,res) => {
        Insolvente.findOne({nombre: req.body.nombre},function(err, insolvente) {
            if (err)
                res.send(err);
               
            if(insolvente){
                res.json({
                    msg_servidor: 'Ese nombre ya esta registrado.'
                });
            }else{

                Insolvente.create({
                    nombre: req.body.nombre,
                    cedula: req.body.cedula,
                    causa: req.body.causa,
                    status: req.body.status,
                    actor: req.body.actor,
                },function(e,insolvente2){
                    if (e) {
                        res.send(e);
                    }
                    res.json(insolvente2);
                });
            }
        });
    });
    
}