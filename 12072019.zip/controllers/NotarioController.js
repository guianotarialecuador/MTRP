const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarNotaria = require('../middlewares/VerificarNotaria');

module.exports = (app,User,Notario) => {
    
    app.get('/api/notarios', verificarToken(User),verificarNotaria(User),(req,res) => {
        Notario.find({notaria: req.header("notaria")},function(err,notarios){
            if (err)
                res.send(err);

            res.json(notarios);
        });
    });

    app.post('/api/notarios',verificarToken(User),verificarNotaria(User),(req,res) => {
        Notario.create({
            nombre: req.body.nombre,
            notaria: req.header("notaria"),
            genero: req.body.genero,
            leyenda: req.body.leyenda,
            firma: req.body.firma,
        },function(e,notaria2){
            if (e) {
                res.send(e);
            }
            res.json(notaria2);
        });
    });

    app.put('/api/notarios/:id',verificarToken(User),verificarNotaria(User),(req,res) => {

        Notario.findById(req.params.id,function(err,notario) {
            if (err)
                res.send(err);
            
            if (notario) {
                if (req.body.nombre) {
                    notario.nombre = req.body.nombre;
                }
                if (req.body.genero) {
                    notario.genero = req.body.genero;
                }
                if (req.body.leyenda) {
                    notario.leyenda = req.body.leyenda;
                }
                if (req.body.firma) {
                    notario.firma = req.body.firma;
                }

                notario.save((e)=>{
                    if (e)
                        res.send(e);
                    res.json(notario);
                })
            }else{
                res.json({
                    msg_servidor: 'Ese notario no Existe.'
                });
            }

        });

    });
    
}