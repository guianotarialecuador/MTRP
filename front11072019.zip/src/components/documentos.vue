<template>
    <div class="container  border-dark">
        <div class="row bg-primary border rounded-top mt-0">
            <h5 class="col-9 py-1">
                <center>
                    Documentos
                </center>
            </h5>
            <div class="col-3 py-1 rounded">
                <input type="text" id="buscador" placeholder="Buscar..." v-model="busqueda">
            </div>
        </div>
        <div class="row rounded-bottom">
            <div class="col-12 p-0">
                <div class="responsive-table p-0">
                    <table class="table py-0">
                        <thead class="py-0 headerX">
                            <tr class="py-0">
                                <th class="py-0 border">
                                    <center>
                                        <strong>Documento</strong>
                                    </center>
                                </th>
                                <th class="py-0 border">
                                    <center>
                                        <strong>W</strong>
                                    </center>
                                </th>
                                <th class="py-0 border">
                                    <center>
                                        <strong>U</strong>
                                    </center>
                                </th>
                                <th class="py-0 border">
                                    <center>
                                        <strong>Cambio</strong>
                                    </center>
                                </th>
                                <th class="py-0 border">
                                    <center>
                                        <strong>Editar</strong>
                                    </center>
                                </th>
                            </tr>
                        </thead>
                        <tbody class="py-0">
                            <tr v-for="(doc,index) in documentos" :key="index" class="py-0">
                                <td class="py-0 border">
                                    {{ doc.tramite }} - {{ doc.factura }}
                                </td>
                                <td class="py-0 border">
                                    <a target="_blank" class="btn btn-primary p-0" @click="abrirWord(doc._id)">
                                        W
                                    </a>
                                </td>
                                <td class="py-0 border">
                                    {{ doc.fecha_creacion }} - {{ doc.creador }}
                                </td>
                                <td class="py-0 border">
                                    {{ doc.fecha_cambio }} - {{ doc.cambiador }}
                                </td>
                                <td class="py-0 border">
                                    <b-btn variant="success" class="p-0 m-1" @click="editar(index)">
                                        Editar
                                    </b-btn>
                                    <b-btn variant="danger" class="p-0 m-1" @click="eliminar(index)">
                                        -
                                    </b-btn>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios'

export default {
    name: "documentos",
    props: ['miusuario'],
    mounted(){
        //PRUEBA EN MAQUINA
        this.getDocumentos();
        //FIN
    },
    data(){
        return {
            documentos: [],
            busqueda: ''
        }
    },
    methods: {
        eliminar(index){
            axios.delete('/api/documentos/'+this.documentos[index]._id,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getDocumentos();
            }).catch((e)=>{
                if (e) {
                    throw e;
                }
            });
        },
        abrirWord(idoc){
            axios.get('/word/'+idoc,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                setTimeout(() => {
                    window.open('/reports/'+res.data.notaria+'/'+res.data.tramite+'-'+res.data.factura+'.docx','_blank')
                }, 2000);
            }).catch((e)=>{
                console.log(e);
            });
        },
        getDocumentos(){
            axios.get('/api/documentos',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.documentos = res.data;
            }).catch((e)=>{
                if (e) {
                    throw e;
                }
            });
        },
        editar(index){
            this.documentos[index].fichero = '';
            this.$emit('documentoE',this.documentos[index]);
        }
    }
}
</script>
<style>
#buscador {
    background-image: url('~@/assets/searchIcon.svg');
    background-position: 0px 5px;
    background-repeat: no-repeat;
    background-size: 30px;
    padding-left: 35px;
}

.headerX {
background: rgba(242,246,248,1);
background: -moz-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(242,246,248,1)), color-stop(16%, rgba(216,225,231,1)), color-stop(51%, rgba(181,198,208,1)), color-stop(100%, rgba(224,239,249,1)));
background: -webkit-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -o-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -ms-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: linear-gradient(to bottom, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f2f6f8', endColorstr='#e0eff9', GradientType=0 ); 
}

</style>
