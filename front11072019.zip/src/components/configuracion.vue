<template>
    <div class="container border-dark">
        <div role="tablist">

            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-1 variant="primary">Notarios</b-button>
                </b-card-header>
                <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table border">
                                        <thead class="bg-secondary">
                                            <tr>
                                                <th>
                                                    Nombre
                                                </th>
                                                <th>
                                                    Genero
                                                </th>
                                                <th>
                                                    Leyenda
                                                </th>
                                                <th>
                                                    Firma
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(nota,index) in notarios" :key="index">
                                                <td>
                                                    {{nota.nombre}}
                                                </td>
                                                <td>
                                                    {{nota.genero}}
                                                </td>
                                                <td>
                                                    {{nota.leyenda}}
                                                </td>
                                                <td>
                                                    {{nota.firma}}
                                                </td>
                                                <td>
                                                    <b-btn @click="showModal2(index)" variant="primary" class="m-1">
                                                        Editar
                                                    </b-btn>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <b-btn @click="showModal1" variant="primary" class="m-1">
                            Crear Notario
                        </b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>

            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-2 variant="primary">Tramites</b-button>
                </b-card-header>
                <b-collapse id="accordion-2" visible accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table border">
                                        <thead class="bg-secondary">
                                            <tr>
                                                <th>
                                                    Nombre
                                                </th>
                                                <th>
                                                    Template
                                                </th>
                                                <th>
                                                    P. Juridica
                                                </th>
                                                <th>
                                                    P. Natural
                                                </th>
                                                <th>
                                                    Menor de Edad
                                                </th>
                                                <th>
                                                    Minuta
                                                </th>
                                                <th>
                                                    Declaracion
                                                </th>
                                                <th>
                                                    Manejo de Capital
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(tramite,index) in tramites" :key="index">
                                                <td>
                                                    {{tramite.nombre}}
                                                </td>
                                                <td>
                                                    {{tramite.template}}
                                                </td>
                                                
                                                <td>
                                                    {{tramite.persona_juridica}}
                                                </td>
                                                <td>
                                                    {{tramite.persona_natural}}
                                                </td>
                                                <td>
                                                    {{tramite.menor}}
                                                </td>
                                                <td>
                                                    {{tramite.minuta}}
                                                </td>
                                                <td>
                                                    {{tramite.declaracion}}
                                                </td>
                                                <td>
                                                    {{tramite.manejo_capital}}
                                                </td>

                                                <td>
                                                    <b-btn @click="showModal4(index)" variant="primary" class="m-1">
                                                        Editar
                                                    </b-btn>                                                    
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <b-btn @click="showModal3" variant="primary" class="m-1">
                            Crear Tramite
                        </b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>

            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-3 variant="primary">Templates</b-button>
                </b-card-header>
                <b-collapse id="accordion-3" visible accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table border">
                                        <thead class="bg-secondary">
                                            <tr>
                                                <th>
                                                    Nombre
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(template,index) in templates" :key="index">
                                                <td>
                                                    {{template.nombre}}
                                                </td>
                                                <td>
                                                    
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <b-btn @click="showModal5" variant="primary" class="m-1">
                            Crear Template
                        </b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>

            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-4 variant="primary">Insolventes</b-button>
                </b-card-header>
                <b-collapse id="accordion-4" visible accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    Nombre
                                                </th>
                                                <th>
                                                    Cedula
                                                </th>
                                                <th>
                                                    Actor
                                                </th>
                                                <th>
                                                    Status
                                                </th>
                                                <th>
                                                    Numero de Causa
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(insolvente,index) in insolventes" :key="index">
                                                <td>
                                                    {{insolvente.nombre}}
                                                </td>
                                                <td>
                                                    {{insolvente.cedula}}
                                                </td>
                                                <td>
                                                    {{insolvente.actor}}
                                                </td>
                                                <td>
                                                    {{insolvente.status}}
                                                </td>
                                                <td>
                                                    {{insolvente.causa}}
                                                </td>
                                                <td>
                                                    <b-btn @click="delInsolvente(index)">Eliminar</b-btn>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <b-btn @click="showModal6" variant="primary">Registrar Insolvente</b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>

        </div>

        <b-modal ref="notarioMod1" hide-footer title="Nuevo Notario">
            <form class="row" @submit.prevent="crearNotario">
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" class="form-control" v-model="notarioN.nombre">
                </div>
                <div class="form-group col-md-6">
                    Genero
                    <select class="form-control" v-model="notarioN.genero">
                        <option>El Notario</option>
                        <option>La Notaria</option>
                    </select>
                </div>
                <div class="form-group col-12">
                    Leyenda
                    <textarea class="form-control" v-model="notarioN.leyenda" rows="3"></textarea>
                </div>
                <div class="form-group col-12">
                    Firma
                    <textarea class="form-control" v-model="notarioN.firma" rows="3"></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Crear</button>
                </div>
            </form>
        </b-modal>
        <b-modal ref="notarioMod2" hide-footer title="Editar Notario">
            <form v-if="notarioE" class="row" @submit.prevent="editarNotario">
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" class="form-control" v-model="notarioE.nombre">
                </div>
                <div class="form-group col-md-6">
                    Genero
                    <select class="form-control" v-model="notarioE.genero">
                        <option>El Notario</option>
                        <option>La Notaria</option>
                    </select>
                </div>
                <div class="form-group col-12">
                    Leyenda
                    <textarea class="form-control" v-model="notarioE.leyenda" rows="3"></textarea>
                </div>
                <div class="form-group col-12">
                    Firma
                    <textarea class="form-control" v-model="notarioE.firma" rows="3"></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </b-modal>
        
        <b-modal ref="tramiteMod1" hide-footer title="Nuevo Tramite">
            <form class="row" @submit.prevent="crearTramite">
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" class="form-control" v-model="tramiteN.nombre">
                </div>
                <div class="form-group col-md-6">
                    Template
                    <select class="form-control" v-model="tramiteN.template">
                        <option v-for="(template,index) in templates" :key="index">
                            {{ template.nombre }}
                        </option>
                    </select>
                </div>

                
                <div class="form-group col-md-6">
                    Incluir Persona Juridica
                    <select class="form-control" v-model="tramiteN.persona_juridica">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Persona Natural
                    <select class="form-control" v-model="tramiteN.persona_natural">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Menor
                    <select class="form-control" v-model="tramiteN.menor">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Minuta
                    <select class="form-control" v-model="tramiteN.minuta">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Declaracion
                    <select class="form-control" v-model="tramiteN.declaracion">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Manejo de Capital
                    <select class="form-control" v-model="tramiteN.manejo_capital">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>

                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Crear</button>
                </div>
            </form>
        </b-modal>
        <b-modal ref="tramiteMod2" hide-footer title="Editar Tramite">
            <form v-if="tramiteE" class="row" @submit.prevent="editarTramite">
                <div class="form-group col-md-6">
                    Nombre
                    <input disabled type="text" class="form-control" v-model="tramiteE.nombre">
                </div>
                <div class="form-group col-md-6">
                    Template
                    <select class="form-control" v-model="tramiteE.template">
                        <option v-for="(template,index) in templates" :key="index">
                            {{ template.nombre }}
                        </option>
                    </select>
                </div>
                
                <div class="form-group col-md-6">
                    Incluir Persona Juridica
                    <select class="form-control" v-model="tramiteE.persona_juridica">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Persona Natural
                    <select class="form-control" v-model="tramiteE.persona_natural">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Menor
                    <select class="form-control" v-model="tramiteE.menor">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Minuta
                    <select class="form-control" v-model="tramiteE.minuta">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Declaracion
                    <select class="form-control" v-model="tramiteE.declaracion">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    Incluir Manejo de Capital
                    <select class="form-control" v-model="tramiteE.manejo_capital">
                        <option>SI</option>
                        <option>NO</option>
                    </select>
                </div>

                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </b-modal>
        
        <b-modal ref="templateMod1" hide-footer title="Nuevo Template">
            <form class="row" @submit.prevent="crearTemplate">
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" class="form-control" v-model="templateN.nombre">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Crear</button>
                </div>
            </form>
        </b-modal>

        <b-modal ref="insolventeMod1" hide-footer title="Registrar Insolvente">
            <form class="row" @submit.prevent="crearInsolvente">
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" class="form-control" v-model="insolventeN.nombre">
                </div>
                <div class="form-group col-md-6">
                    Cedula
                    <input type="text" class="form-control" v-model="insolventeN.cedula">
                </div>
                <div class="form-group col-md-6">
                    No. Causa
                    <input type="text" class="form-control" v-model="insolventeN.causa">
                </div>
                <div class="form-group col-md-6">
                    Status
                    <input type="text" class="form-control" v-model="insolventeN.status">
                </div>
                <div class="form-group col-md-6">
                    Actor
                    <input type="text" class="form-control" v-model="insolventeN.actor">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Crear</button>
                </div>
            </form>
        </b-modal>
    </div>
</template>
<script>
import axios from 'axios'

export default {
    name: 'configuracion',
    props: ['miusuario'],
    data(){
        return {
            notarioE: null,
            tramiteE: null,

            tramiteN: {
                nombre: '',
                template: '',

                persona_juridica: 'SI',
                persona_natural: 'SI',
                menor: 'SI',
                minuta: 'SI',
                declaracion: 'SI',
                manejo_capital: 'SI',
            },
            templateN: {
                nombre: ''
            },
            notarioN: {
                nombre: '',
                genero: '',
                leyenda: '',
                firma: '',
            },
            insolventeN: {
                nombre: '',
                cedula: '',
                causa: '',
                status: '',
                actor: '',
            },

            tramites: [],
            templates: [],
            notarios: [],
            insolventes: [],
        }
    },
    mounted(){
        this.getTemplates();
        this.getTramites();
        this.getNotarios();
        this.getInsolventes();
    },
    methods: {
        delInsolvente(index){
            axios.delete('/api/insolventes/'+this.insolventes[index]._id,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getInsolventes();
            }).catch((e)=>{
                console.log(e);
            });
        },
        crearNotario(){
            axios.post('/api/notarios',this.notarioN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getNotarios();
                this.notarioN = {
                    nombre: '',
                    genero: '',
                    leyenda: '',
                    firma: '',
                }
                this.hideModal1();
            }).catch((e)=>{
                console.log(e);
            });
        },
        editarNotario(){
            axios.put('/api/notarios/'+this.notarioE._id,this.notarioE,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getNotarios();
                this.notarioE = null;
                this.hideModal2();
            }).catch((e)=>{
                console.log(e);
            });
        },
        
        crearTramite(){
            axios.post('/api/tramites',this.tramiteN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getTramites();
                this.tramiteN = {
                    nombre: '',
                    template: '',

                    persona_juridica: 'SI',
                    persona_natural: 'SI',
                    menor: 'SI',
                    minuta: 'SI',
                    declaracion: 'SI',
                    manejo_capital: 'SI',
                }
                this.hideModal3();
            }).catch((e)=>{
                console.log(e);
            });
        },
        editarTramite(){
            axios.put('/api/tramites/'+this.tramiteE._id,this.tramiteE,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getTramites();
                this.tramiteE = null;
                this.hideModal4();
            }).catch((e)=>{
                console.log(e);
            });
        },

        crearTemplate(){
            axios.post('/api/templates',this.templateN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getTemplates();
                this.templateN = {
                    nombre: '',
                }
                this.hideModal5();
            }).catch((e)=>{
                console.log(e);
            });
        },
        crearInsolvente(){
            axios.post('/api/insolventes',this.insolventeN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.getInsolventes();
                this.insolventeN = {
                    nombre: '',
                    cedula: '',
                    causa: '',
                    status: '',
                    actor: '',
                };
                this.hideModal6();
            }).catch((e)=>{
                console.log(e);
            });
        },
        
        showModal1(){
            this.$refs.notarioMod1.show();
        },
        hideModal1(){
            this.$refs.notarioMod1.hide();
        },
        showModal2(index){
            this.notarioE = this.notarios[index];
            this.$refs.notarioMod2.show();
        },
        hideModal2(){
            this.notarioE = null;
            this.$refs.notarioMod2.hide();
        },
        
        showModal3(){
            this.$refs.tramiteMod1.show();
        },
        hideModal3(){
            this.$refs.tramiteMod1.hide();
        },
        showModal4(index){
            this.tramiteE = this.tramites[index];
            this.$refs.tramiteMod2.show();
        },
        hideModal4(){
            this.tramiteE = null;
            this.$refs.tramiteMod2.hide();
        },

        showModal5(){
            this.$refs.templateMod1.show();
        },
        hideModal5(){
            this.$refs.templateMod1.hide();
        },

        showModal6(){
            this.$refs.insolventeMod1.show();
        },
        hideModal6(){
            this.$refs.insolventeMod1.hide();
        },

        getTramites(){
            axios.get('/api/tramites',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.tramites = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        getTemplates(){
            axios.get('/api/templates',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.templates = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        getNotarios(){
            axios.get('/api/notarios',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.notarios = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        getInsolventes(){
            axios.get('/api/insolventes',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.insolventes = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
    }
}
</script>
