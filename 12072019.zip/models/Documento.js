module.exports = mongoose => {

    let conyugueSchema = new mongoose.Schema({
        nombre:String,
        edad: String,
        edad_l: String,
        direccion: String,
        telefono: String,
        telefono_l: String,
        email: String,
        tratamiento: String,
        cedula: String,
        cedula_l: String,
        pasaporte:String,
        ocupacion: String,
        idioma: String,
        nacionalidad: String,
    });
    
    let testigoSchema = new mongoose.Schema({
        nombre:String,
        edad: String,
        edad_l: String,
        direccion: String,
        telefono: String,
        telefono_l: String,
        email: String,
        tratamiento: String,
        cedula: String,
        cedula_l: String,
        pasaporte:String,
        estado_civil: String,
        ocupacion: String,
        conyuge: {conyugueSchema},
        idioma: String,
        nacionalidad: String,
    });

    let abogadoSchema = new mongoose.Schema({
        nombre:String,
        matricula: String,
        titulo: String,
        calidad: String,
    });

    let personaSchema = new mongoose.Schema({
        tipo: String,
        nombre:String,
        edad: String,
        edad_l: String,
        direccion: String,
        calidad: String,
        telefono: String,
        telefono_l: String,
        email: String,
        tratamiento: String,
        declaracion: String,
        testigos: [testigoSchema],
        representados: [testigoSchema],
        puede_firmar: String,
        cedula: String,
        cedula_l: String,
        pasaporte:String,
        estado_civil: String,
        ocupacion: String,
        conyuge: {conyugueSchema},
        ruc: String,
        razon_social: String,
        direccion_empresarial: String,
        idioma: String,
        nacionalidad: String,
        titulo: String,
        votacion: String,
        tipo_otorgante: String,

        tratamiento_juridico: String,
    });
    
    let menorSchema = new mongoose.Schema({
        tratamiento: String,
        nombre:String,
        edad: String,
        edad_l: String,
        direccion: String,
        fecha_salida: String,
        fecha_retorno: String,
        pais_desino: String,
        tutor: String,
        aerolinea: String,
        tutor_direccion: String,
        tutor_telefono: String,
        tutor_telefono_l: String,
        tutor_email: String,
        motivo_viaje: String,

        acompanante_nombre: String,
        acompanante_relacion: String,
        acompanante_cedula: String,
        acompanante_direccion: String,
        acompanante_telefono: String,
        acompanante_telefono_l: String,
        acompanante_email: String,

        cedula: String,
        cedula_l: String,
        pasaporte:String,
        idioma: String,
        nacionalidad: String,
    });

    let esquema = new mongoose.Schema({
        notaria: String,
        tramite: String,
        tramite_numero: String,
        factura: String,
        copias: String,
        copias_l: String,
        lugar: String,
        fecha: String,
        hora: String,
        anio: String,
        referencia: String,
        consecutivo: String,
        
        minuta: String,
        cuantia: String,
        capital_aumento: String,
        capital_actual: String,
        capital_final: String,

        denominado: String,

        notario_genero: String, //el/la notario...
        notario_leyenda: String,// lo que va en eltexto
        notario_firma: String,//lo que va en la firma

        otorgantes: [personaSchema],
        otorgantesj: [personaSchema],

        favorecidos: [personaSchema],
        favorecidosj: [personaSchema],

        menores: [menorSchema],

        otorgante: {personaSchema},
        otorgantej: {personaSchema},

        favorecido: {personaSchema},
        favorecidoj: {personaSchema},

        menor: {menorSchema},

        cantidad_comparecientes: Number,
        cantidad_otorgantes: Number,
        cantidad_favorecidos: Number,
        cantidad_menores: Number,

        abogado: String,

        template:String,
        
        creador:String,
        fecha_creacion:String,
        cambiador:String,
        fecha_cambio:String,
    });

    return mongoose.model('Documentos',esquema);
}