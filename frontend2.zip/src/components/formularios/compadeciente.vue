<template>
    <form class="row" @submit.prevent="enviar">
        <div class="form-group col-md-6">
            Tratamiento
            <select class="form-control" v-model="compadecienteForm.tratamiento">
                <option v-for="(p,index) in prefijos" :key="index">
                    {{ p }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-6">
            Titulo
            <select class="form-control" v-model="compadecienteForm.titulo">
                <option v-for="(t,index) in titulos" :key="index">
                    {{ t }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-4">
            Documento
            <select class="form-control" v-model="compadecienteForm.documento_tipo">
                <option v-for="(d,index) in documentos" :key="index">
                    {{ d }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-4">
            Nro.
            <!-- espacio provicional -->
            <span v-if="compadecienteForm.documento == '1723413504' && compadecienteForm.documento_tipo == 'cédula de ciudadanía'" class="text-danger">*INSOLVENTE</span>
            <!-- espacio provicional -->
            <input type="text" @keyup="verificarCiudadano" class="form-control" placeholder="Nro de Documento" v-model="compadecienteForm.documento">
        </div>
        <div class="form-group col-md-4">
            Certificado de Votacion
            <input type="text" class="form-control" placeholder="Certificado de Votacion" v-model="compadecienteForm.votacion">
        </div>

        <div class="form-group col-12">
            Nombres
            <input type="text" class="form-control" placeholder="Nombres" v-model="compadecienteForm.nombre">
        </div>

        <div class="form-group col-md-6">
            Estado Civil
            <select class="form-control" v-model="compadecienteForm.estado_civil">
                <option v-for="(e,index) in estados" :key="index">
                    {{ e }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-6">
            Nacionalidad
            <input type="text" class="form-control" placeholder="Nacionalidad" v-model="compadecienteForm.nacionalidad">
        </div>
        <hr class="col-10">

        <div class="form-group col-10">
            Ocupación
            <select v-model="compadecienteForm.ocupacion" class="form-control">
                <option v-for="(o,index) in ocupaciones" :key="index">
                    <span v-if="compadecienteForm.tratamiento == 'SEÑOR'">
                        {{ o.masculino }}
                    </span>
                    <span v-else>
                        {{ o.femenino }}
                    </span>
                </option>
            </select>
        </div>
        <div class="col-2">
            <b-btn @click="showModal1" variant="success rounded-circle" v-b-tooltip.hover title="Añadir Ocupacion" class="mt-4">
                +
            </b-btn>
        </div>
        <hr class="col-10">
        
        <div class="form-group col-12">
            Domicilio
            <input type="text" class="form-control" placeholder="Domicilio" v-model="compadecienteForm.direccion">
        </div>

        <div class="form-group col-md-4">
            Teléfono
            <input type="text" class="form-control" placeholder="Teléfono" v-model="compadecienteForm.telefono">
        </div>
        <div class="form-group col-md-4">
            Celular
            <input type="text" class="form-control" placeholder="Celular" v-model="compadecienteForm.celular">
        </div>
        <div class="form-group col-md-4">
            Correo Electrónico
            <input type="text" class="form-control" placeholder="Correo Electronico" v-model="compadecienteForm.email">
        </div>

        <div class="form-group col-md-6">
            No Puede o No Sabe Firmar
            <input type="text" class="form-control" placeholder="Llenar solo si nesesita un testigo" v-model="compadecienteForm.puede_firmar">
        </div>
        <div class="form-group col-md-6">
            Testigo
            <b-btn variant="success" class="rounded-circle mx-1" @click="showModal2">
                +
            </b-btn>
            <br v-if="compadecienteForm.testigos.length > 0">

            <table v-if="compadecienteForm.testigos.length > 0">
                <tr v-for="(t,index) in compadecienteForm.testigos" :key="index">
                    <td class="px-2">
                        {{ t.nombre }}
                    </td>
                    <td class="px-2">
                        <b-btn @click="showModal3(index)" class="m-1" variant="primary">
                            Editar
                        </b-btn>
                        <b-btn @click="removerTestigo(index)" class="m-1" variant="danger">
                            Quitar
                        </b-btn>
                    </td>
                </tr>
            </table>
        </div>
        <div class="form-group col-12">
            Forma de Compadecer
            <textarea class="form-control" placeholder="Forma de Compadecer" v-model="compadecienteForm.forma_compadecer" rows="4"></textarea>
        </div>
        
        <div class="form-group col-md-4">
            En calidad de
            <input type="text" class="form-control" placeholder="En calidad de..." v-model="compadecienteForm.calidad">
        </div>
        <div class="form-group col-md-8">
            Otra Calidad/Texto Complementario
            <textarea type="text" class="form-control" placeholder="Otra Calidad/Texto Complementario" v-model="compadecienteForm.otra_calidad" rows="3"></textarea>
        </div>

        <hr class="col-10">

        <div class="col-12">
            <button v-if="!persona" type="submit" class="btn btn-primary">Guardar</button>
            <button v-else @click="editar" class="btn btn-primary">Guardar</button>
        </div>

        <b-modal class="border-dark" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" ref="modOc1" hide-footer title="Añadir Ocupación/Profesión">
            <ocupacion :miusuario="miusuario" @nuevaOcupacion="hideModal1"></ocupacion>
        </b-modal>
        <b-modal class="border-dark" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" ref="modOc2" hide-footer title="Añadir Testigo">
            <testigo :miusuario="miusuario" @testigoN="nuevoTestigo"></testigo>
        </b-modal>
        <b-modal class="border-dark" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" ref="modOc3" hide-footer title="Añadir Testigo">
            <testigo :miusuario="miusuario" v-if="testigoX" @testigoE="editarTestigo" :testigoactual="testigoX"></testigo>
        </b-modal>
    </form>
</template>
<script>
import axios from 'axios'

import ocupacion from './ocupacion'
import testigo from './testigo'

export default {
    name: 'compadeciente',
    components: {
        ocupacion,
        testigo
    },
    props: ['persona','tipo','miusuario'],
    data(){
        return {
            prefijos: [
                'SEÑOR',
                'SEÑORA'
            ],
            titulos: [
                'ABOGADO',
                'INGENIERO',
                'DOCTOR',
                'LICENCIADO',
                'ECONOMISTA'
            ],
            documentos: [
                'cédula de ciudadanía',
                'pasaporte'
            ],
            estados: [
                'soltero',
                'divorciado',
                'casado',
                'viudo'
            ],
            ocupaciones: [],

            compadecienteForm: {
                tipo: '',
                genero: 'M',
                tratamiento: '',
                titulo: '',
                documento: '',
                documento_tipo: '',
                votacion: '',
                nombre: '',
                estado_civil: '',
                nacionalidad: '',
                ocupacion: '',
                direccion: '',
                telefono: '',
                celular: '',
                email: '',
                puede_firmar: '',
                forma_compadecer: '',
                calidad: '',
                otra_calidad: '',

                testigos: [],
            },

            testigoX: null,
            testigoIndex: -1
        }
    },
    mounted(){
        this.cargarOcupaciones();

        if (this.tipo) {
            this.compadecienteForm.tipo = this.tipo;
        }else{
            this.compadecienteForm.tipo = 'NATURAL';
        }
        if (this.persona) {
            this.compadecienteForm = this.persona
        }
    },
    methods: {
        verificarCiudadano(){
            //provicional
            if (this.compadecienteForm.documento == '1723413504' && this.compadecienteForm.documento_tipo == 'cédula de ciudadanía') {
                this.compadecienteForm.nombre = 'JOSE FRANCISCO CRUZ CORRO';
                this.compadecienteForm.tratamiento = 'SEÑOR';
                this.compadecienteForm.titulo = 'INGENIERO';
                this.compadecienteForm.estado_civil = 'soltero';
                this.compadecienteForm.nacionalidad = 'ECUATORIANO';
                this.compadecienteForm.ocupacion = 'OCUPACIÓN Programador';
                this.compadecienteForm.direccion = 'QUITO';
                this.compadecienteForm.telefono = '02555666';
                this.compadecienteForm.celular = '0999555666';
                this.compadecienteForm.email = 'miemail@gmail.com';
            }
            //fin provicional
        },
        cargarOcupaciones(){
            axios.get('/api/ocupaciones',{headers:{user:this.miusuario.user,token:this.miusuario.token}}).then((res)=>{
                this.ocupaciones = res.data;
            }).catch((e)=>{
                if (e) {
                    throw e;
                }
            });
        },
        showModal1(){
            this.$refs.modOc1.show();
        },
        hideModal1(){
            this.$refs.modOc1.hide();
        },
        showModal2(){
            this.$refs.modOc2.show();
        },
        hideModal2(){
            this.$refs.modOc2.hide();
        },
        showModal3(index){
            this.testigoX = this.compadecienteForm.testigos[index];
            this.$refs.modOc3.show();
            this.testigoIndex = index;
        },
        hideModal3(){
            this.$refs.modOc3.hide();
        },
        nuevoTestigo(t){
            this.compadecienteForm.testigos.push(t);
            this.hideModal2();
        },
        editarTestigo(t){
            this.compadecienteForm.testigos[this.testigoIndex] = t;
            this.testigoX = null;
            this.testigoIndex = -1;
            this.hideModal3();
        },
        removerTestigo(index){
            this.compadecienteForm.testigos.splice(index,1);
            this.testigoX = null;
            this.testigoIndex = -1;
        },
        editar(){
            this.$emit('personaE',this.compadecienteForm);
        },
        enviar(){
            this.$emit('personaN',this.compadecienteForm);
            this.compadecienteForm = {
                tipo: '',
                tratamiento: '',
                titulo: '',
                documento: '',
                documento_tipo: '',
                votacion: '',
                nombre: '',
                estado_civil: '',
                nacionalidad: '',
                ocupacion: '',
                direccion: '',
                telefono: '',
                celular: '',
                email: '',
                puede_firmar: '',
                forma_compadecer: '',
                calidad: '',
                otra_calidad: '',

                testigos: [],
            };
        }
    }
}
</script>
