module.exports = mongoose => {
    let esquema = new mongoose.Schema({
        nombre: String,
        notaria: String,
        template: String,

        persona_natural: String,
        persona_juridica: String,
        menor: String,
        minuta: String,
        declaracion: String,
        manejo_capital: String,
    });

    return mongoose.model('Tramites',esquema);
}