<template>
    <div class="container">
        <div class="row bg-primary">

            <div class="form-group col-lg-2">
                Tipo
                <select v-model="documento.tramite" class="form-control">
                    <option v-for="(tram,index) in tramites" :key="index">
                        {{tram.nombre}}
                    </option>
                </select>
            </div>
            <div class="form-group col-lg-2">
                Plantilla
                <select v-model="documento.template" class="form-control">
                    <option v-for="(tram,index) in templates" :key="index">
                        {{tram.nombre}}
                    </option>
                </select>
            </div>
            <div class="form-group col-lg-2">
                Notario/a
                <select v-model="documento.notario_genero" class="form-control">
                    <option>
                        El Notario
                    </option>
                    <option>
                        La Notaria
                    </option>
                </select>
            </div>
            <div class="form-group col-lg-2">
                Notario Leyenda
                <select v-model="documento.notario_leyenda" class="form-control">
                    <option v-for="(nota,index) in notarios" :key="index">
                        {{ nota.leyenda }}
                    </option>
                </select>
            </div>
            <div class="form-group col-lg-2">
                Notario Firma
                <select v-model="documento.notario_firma" class="form-control">
                    <option v-for="(nota,index) in notarios" :key="index">
                        {{ nota.firma }}
                    </option>
                </select>
            </div>
            <div class="form-group col-lg-2">
                No. Tramite
                <input type="text" class="form-control" v-model="documento.tramite_numero">
            </div>
            <div class="form-group col-lg-2">
                Factura
                <input type="text" class="form-control" v-model="documento.factura">
            </div>
            <div class="form-group col-lg-2">
                Copias
                <input type="text" class="form-control" v-model="documento.copias">
            </div>
            <div class="form-group col-lg-2">
                Protocolo
                <input type="text" class="form-control" v-model="documento.referencia">
            </div>

            <div class="col-12">
                <b-btn @click="showModal1" class="rounded m-1" variant="outline-light">
                    + Persona Natural
                </b-btn>
                <b-btn @click="showModal2" class="rounded m-1" variant="outline-light">
                    + Persona Juridica
                </b-btn>
                <b-btn @click="showModal5" class="rounded m-1" variant="outline-light">
                    + Menor de Edad
                </b-btn>
            </div>

        </div>
        <div class="row my-1" v-if="documento.otorgantes.length > 0">
            <div class="bg-primary col-12 text-center">
                <strong>OTORGANTES</strong>
            </div>
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table border">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Tipo</th>
                                <th>Nombre</th>
                                <th>Calidad</th>
                                <th>Cedula</th>
                                <th>RUC</th>
                                <th>Pasaporte</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(o,index) in documento.otorgantes" :key="index">
                                <td>
                                    {{o.tipo}}
                                </td>
                                <td>
                                    {{o.nombre}}
                                </td>         
                                <td>
                                    {{o.calidad}}
                                </td>
                                <td>
                                    {{o.cedula}}
                                </td>
                                <td>
                                    {{o.ruc}}
                                </td>   
                                <td>
                                    {{o.pasaporte}}
                                </td>  
                                <td>
                                    <button @click="showModal3(index)" class="btn btn-primary m-1">
                                        Editar
                                    </button>
                                    <button @click="deleteCompareciente(index)" class="btn btn-danger m-1">
                                        Eliminar
                                    </button>
                                </td>          
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row my-1" v-if="documento.favorecidos.length > 0">
            <div class="bg-primary col-12 text-center">
                <strong>A Favor</strong>
            </div>
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table border">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Tipo</th>
                                <th>Nombre</th>
                                <th>Calidad</th>
                                <th>Cedula</th>
                                <th>RUC</th>
                                <th>Pasaporte</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(o,index) in documento.favorecidos" :key="index">
                                <td>
                                    {{o.tipo}}
                                </td>
                                <td>
                                    {{o.nombre}}
                                </td>         
                                <td>
                                    {{o.calidad}}
                                </td>
                                <td>
                                    {{o.cedula}}
                                </td>
                                <td>
                                    {{o.ruc}}
                                </td>   
                                <td>
                                    {{o.pasaporte}}
                                </td>  
                                <td>
                                    <button @click="showModal4(index)" class="btn btn-primary m-1">
                                        Editar
                                    </button>
                                    <button @click="deleteCompareciente2(index)" class="btn btn-danger m-1">
                                        Eliminar
                                    </button>
                                </td>          
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row my-1" v-if="documento.menores.length > 0">
            <div class="bg-primary col-12 text-center">
                <strong>Menores</strong>
            </div>
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table border">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Tutor</th>
                                <th>Nombre</th>
                                <th>Cedula</th>
                                <th>Pasaporte</th>
                                <th>Pais Destino</th>
                                <th>Fecha de Salida</th>
                                <th>Fecha de Retorno</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(o,index) in documento.menores" :key="index">
                                <td>
                                    {{o.tutor}}
                                </td>
                                <td>
                                    {{o.nombre}}
                                </td>  
                                <td>
                                    {{o.cedula}}
                                </td>
                                <td>
                                    {{o.pasaporte}}
                                </td>  
                                <td>
                                    {{o.pais_desino}}
                                </td>  
                                <td>
                                    {{o.fecha_salida}}
                                </td>  
                                <td>
                                    {{o.fecha_retorno}}
                                </td>  
                                <td>
                                    <button @click="showModal6(index)" class="btn btn-primary m-1">
                                        Editar
                                    </button>
                                    <button @click="deleteMenor(index)" class="btn btn-danger m-1">
                                        Eliminar
                                    </button>
                                </td>          
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row my-1">
            <div class="col-md-4">
                Cuantia
                <input type="text" class="form-control" v-model="documento.cuantia">
            </div>
            <div class="col-md-4">
                Compañia
                <input type="text" class="form-control" v-model="documento.denominado">
            </div>
            <div class="col-12">
                Minuta
                <!--<div id="summernote">{{documento.minuta}}</div>-->
                <textarea v-model="documento.minuta" class="form-control" rows="3"></textarea>
            </div>
        </div>
        <div class="row my-1 py-1">
            <div class="col-4">
                Capital Actual
                <input type="text" class="form-control" v-model="documento.capital_actual">
            </div>
            <div class="col-4">
                Aumento de Capital
                <input type="text" class="form-control" v-model="documento.capital_aumento">
            </div>
            <div class="col-4">
                Capital Final
                <input type="text" class="form-control" v-model="documento.capital_final">
            </div>
        </div>
        <div class="row my-2">
            <div class="col-12">
                <b-btn @click="guardar">Guardar</b-btn>
            </div>
        </div>
        <b-modal ref="compMod1" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Agregar Persona Natural">
            <compareciente :miusuario='miusuario' @nuevoCompareciente='addCompareciente' tipo='NATURAL'></compareciente>
        </b-modal>
        <b-modal ref="compMod2" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Agregar Persona Juridica">
            <compareciente :miusuario='miusuario' @nuevoCompareciente='addCompareciente2' tipo='JURIDICO'></compareciente>
        </b-modal>
        <b-modal ref="compMod3" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Editar Persona Natural">
            <compareciente v-if="persona" :persona="persona" :miusuario='miusuario' @nuevoCompareciente='modCompareciente' tipo='NATURAL'></compareciente>
        </b-modal>
        <b-modal ref="compMod4" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Editar Persona Juridica">
            <compareciente v-if="persona" :persona="persona" :miusuario='miusuario' @nuevoCompareciente='modCompareciente2' tipo='JURIDICO'></compareciente>
        </b-modal>
        <b-modal ref="compMod5" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Agregar Menor">
            <menorx :miusuario='miusuario' @nuevoMenor='addMenor'></menorx>
        </b-modal>
        <b-modal ref="compMod6" size="xl" header-bg-variant="primary" body-bg-variant="secondary" hide-footer title="Editar Menor">
            <menorx v-if="menorActual" :persona="menorActual" :miusuario='miusuario' @nuevoMenor='modMenor'></menorx>
        </b-modal>
    </div>
</template>
<script>
import axios from 'axios'

import compareciente from './formularios/compareciente'
import menorx from './formularios/menor'

export default {
    name: 'nuevo-documento',
    props: ['miusuario','docactual'],
    components: {
        compareciente,
        menorx
    },
    data(){
        return {
            tramites: [],
            notarios: [],
            notario: '',
            tramite: null,
            persona: null,
            menorActual: null,
            menorIndex: -1,
            otoIndex: -1,
            favorIndex: -1,
            
            templates: [],

            documento: {
                notaria: '',///
                tramite: '',///
                tramite_numero: '',///
                factura: '',///
                copias: '',///
                lugar: '',
                fecha: '',///
                hora: '',///
                anio: '',///
                referencia: '',///
                consecutivo: '',
                
                minuta: '',///
                cuantia: '',///
                capital_aumento: '',///
                capital_actual: '',//
                capital_final: '',///

                denominado: '',

                notario_genero: '', //el/la notario...
                notario_leyenda: '',// lo que va en eltexto
                notario_firma: '',//lo que va en la firma

                otorgantes: [],
                otorgantesj: [],

                favorecidos: [],
                favorecidosj: [],

                menores: [],

                otorgante: null,
                otorgantej: null,

                favorecido: null,
                favorecidoj: null,

                menor: null,

                cantidad_comparecientes: 0,//
                cantidad_otorgantes: 0,///
                cantidad_favorecidos: 0,//
                cantidad_menores: 0,//

                abogado: null,

                template:'',///
                
                creador:'',//
                fecha_creacion:'',//
                cambiador:'',//
                fecha_cambio:'',//
            },
        }
    },
    mounted(){
        this.getTramites();
        this.getNotarios();
        this.getTemplates();

        if (this.docactual) {
            this.documento = this.docactual;
            //$('#summernote').summernote('code', this.documento.minuta);
        }else{
            /*$(document).ready(function() {
                $('#summernote').summernote();
            });*/
        }
    },
    methods: {
        showModal1(){
            this.$refs.compMod1.show();
        },
        hideModal1(){
            this.$refs.compMod1.hide();
        },
        showModal2(){
            this.$refs.compMod2.show();
        },
        hideModal2(){
            this.$refs.compMod2.hide();
        },
        showModal3(index){
            this.persona = this.documento.otorgantes[index];
            this.otoIndex = index;
            this.$refs.compMod3.show();
        },
        hideModal3(){
            this.$refs.compMod3.hide();
        },
        showModal4(index){
            this.persona = this.documento.favorecidos[index];
            this.favorIndex = index;
            this.$refs.compMod4.show();
        },
        hideModal4(){
            this.$refs.compMod4.hide();
        },
        showModal5(){
            this.$refs.compMod5.show();
        },
        hideModal5(){
            this.$refs.compMod5.hide();
        },
        showModal6(index){
            this.menorActual = this.documento.menores[index];
            this.menorIndex = index;
            this.$refs.compMod6.show();
        },
        getTemplates(){
            axios.get('/api/templates',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.templates = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        hideModal6(){
            this.$refs.compMod6.hide();
        },
        addCompareciente(compa){
            if (compa.tipo_otorgante == 'QUE OTORGA') {
                this.documento.otorgantes.push(compa);
            }else{
                this.documento.favorecidos.push(compa);
            }
            this.hideModal1();
        },
        addMenor(compa){
            this.documento.menores.push(compa);
            this.hideModal5();
        },
        deleteCompareciente(index){
            this.documento.otorgantes.splice(index,1);
        },
        deleteCompareciente2(index){
            this.documento.favorecidos.splice(index,1);
        },
        deleteMenor(index){
            this.documento.menores.splice(index,1);
        },
        modMenor(compa){
            this.documento.menores[this.menorIndex] = compa;
            
            this.menorActual = null;
            this.menorIndex = -1;
            
            this.hideModal6();
        },
        modCompareciente(compa){
            if (compa.tipo_otorgante == this.documento.otorgantes[this.otoIndex].tipo_otorgante) {
                this.documento.otorgantes[this.otoIndex] = compa;
            } else {
                this.documento.otorgantes.splice(this.otoIndex,1);
                if (compa.tipo_otorgante == 'QUE OTORGA') {
                    this.documento.otorgantes.push(compa);
                }else{
                    this.documento.favorecidos.push(compa);
                }
            }

            this.persona = null;
            this.otoIndex = -1;
            
            this.hideModal3();
        },
        addCompareciente2(compa){
            if (compa.tipo_otorgante == 'QUE OTORGA') {
                this.documento.otorgantes.push(compa);
            }else{
                this.documento.favorecidos.push(compa);
            }
            this.hideModal2();
        },
        modCompareciente2(compa){
            this.documento.favorecidos[this.favorIndex] = compa;

            this.persona = null;
            this.favorIndex = -1;
            
            this.hideModal4();
        },
        getTramites(){
            axios.get('/api/tramites',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.tramites = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        getNotarios(){
            axios.get('/api/notarios',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.notarios = res.data;
            }).catch((e)=>{
                console.log(e);
            });
        },
        guardar(){
            this.documento.notaria = this.miusuario.notaria;
            let fechax = new Date();

            this.documento.fecha = this.numeroADias(fechax.getDay()) + ', ' + this.numeroALetras(fechax.getDate()) + ' DE ' + this.numerosAMeses(fechax.getMonth()+1) + ' DEL ' + this.numeroALetras(fechax.getFullYear());
            this.documento.hora = fechax.getHours() + ':' + fechax.getMinutes();
            this.documento.anio = ''+fechax.getFullYear();

            this.documento.cantidad_otorgantes = this.documento.otorgantes.length;
            this.documento.cantidad_comparecientes = this.documento.otorgantes.length;
            this.documento.cantidad_favorecidos = this.documento.favorecidos.length;
            this.documento.cantidad_menores = this.documento.menores.length;

            if (this.documento.cantidad_otorgantes > 0) {
                this.documento.otorgante = this.documento.otorgantes[0];
                for (let i = 0; i < this.documento.cantidad_otorgantes; i++) {
                    this.documento.otorgantes[i].edad_l = this.numeroALetras(this.documento.otorgantes[i].edad);
                    let cedLeter = this.documento.otorgantes[i].cedula.split('');
                    this.documento.otorgantes[i].cedula_l = '';
                    for (let j = 0; j < cedLeter.length; j++) {
                        this.documento.otorgantes[i].cedula_l += this.numeroALetras(cedLeter[j]) + ' ';                        
                    }
                }
            }
            if (this.documento.cantidad_favorecidos > 0) {
                this.documento.favorecido = this.documento.favorecidos[0];
                for (let i = 0; i < this.documento.cantidad_favorecidos; i++) {
                    this.documento.favorecidos[i].edad_l = this.numeroALetras(this.documento.favorecidos[i].edad);
                    let cedLeter = this.documento.favorecidos[i].cedula.split('');
                    this.documento.favorecidos[i].cedula_l = '';
                    for (let j = 0; j < cedLeter.length; j++) {
                        this.documento.favorecidos[i].cedula_l += this.numeroALetras(cedLeter[j]) + ' ';                        
                    }
                }
            }

            if (this.documento.cantidad_menores > 0) {
                this.documento.menor = this.documento.menores[0];
                for (let i = 0; i < this.documento.cantidad_menores; i++) {
                    this.documento.menores[i].edad_l = this.numeroALetras(this.documento.menores[i].edad);
                    let cedLeter = this.documento.menores[i].cedula.split('');
                    this.documento.menores[i].cedula_l = '';
                    for (let j = 0; j < cedLeter.length; j++) {
                        this.documento.menores[i].cedula_l += this.numeroALetras(cedLeter[j]) + ' ';                        
                    }
                }
            }

            //this.documento.minuta = $('#summernote').summernote('code');

            if (this.docactual) {
                this.documento.cambiador = this.miusuario.name;
                this.documento.fecha_cambio = fechax.getFullYear() + '-' + (fechax.getMonth() + 1) + '-' + fechax.getDate() + ' ' + fechax.getHours() + ':' + fechax.getMinutes();

                axios.put('/api/documentos/' + this.documento._id,this.documento,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    this.$emit('documentoE');
                }).catch((e)=>{ 
                    console.log(e);
                });
            } else {
                this.documento.creador = this.miusuario.name;
                this.documento.fecha_creacion = fechax.getFullYear() + '-' + (fechax.getMonth() + 1) + '-' + fechax.getDate() + ' ' + fechax.getHours() + ':' + fechax.getMinutes();

                axios.post('/api/documentos',this.documento,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    this.$emit('documentoN');
                }).catch((e)=>{ 
                    console.log(e);
                });
            }            
        },

        numeroALetras(n){
            if (n + '' == '1') {
                return 'UNO'
            }
            if (n + '' == '2') {
                return 'DOS'
            }
            if (n + '' == '3') {
                return 'TRES'
            }
            if (n + '' == '4') {
                return 'CUATRO'
            }
            if (n + '' == '5') {
                return 'CINCO'
            }
            if (n + '' == '6') {
                return 'SEIS'
            }
            if (n + '' == '7') {
                return 'SIETE'
            }
            if (n + '' == '8') {
                return 'OCHO'
            }
            if (n + '' == '9') {
                return 'NUEVE'
            }
            if (n + '' == '0') {
                return 'CERO'
            }

            if (n + '' == '2019') {
                return 'DOS MIL DIECINUEVE'
            }
            if (n + '' == '2020') {
                return 'DOS MIL VEINTE'
            }
            if (n + '' == '2021') {
                return 'DOS MIL VEINTE Y UNO'
            }

            
            if (n + '' == '11') {
                return 'ONCE'
            }
            if (n + '' == '12') {
                return 'DOCE'
            }
            if (n + '' == '13') {
                return 'TRECE'
            }
            if (n + '' == '14') {
                return 'CATORCE'
            }
            if (n + '' == '15') {
                return 'QUINCE'
            }
            if (n + '' == '16') {
                return 'DIECISEIS'
            }
            if (n + '' == '17') {
                return 'DIECISIETE'
            }
            if (n + '' == '18') {
                return 'DIECIOCHO'
            }
            if (n + '' == '19') {
                return 'DIECINUEVE'
            }
            if (n + '' == '10') {
                return 'DIEZ'
            }

            
            if (n + '' == '21') {
                return 'VEINTE Y UNO'
            }
            if (n + '' == '22') {
                return 'VEINTE Y DOS'
            }
            if (n + '' == '23') {
                return 'VEINTE Y TRES'
            }
            if (n + '' == '24') {
                return 'VEINTE Y CUATRO'
            }
            if (n + '' == '25') {
                return 'VEINTE Y CINCO'
            }
            if (n + '' == '26') {
                return 'VEINTE Y SEIS'
            }
            if (n + '' == '27') {
                return 'VEINTE Y SIETE'
            }
            if (n + '' == '28') {
                return 'VEINTE Y OCHO'
            }
            if (n + '' == '29') {
                return 'VEINTE Y NUEVE'
            }
            if (n + '' == '20') {
                return 'VEINTE'
            }
            
            if (n + '' == '30') {
                return 'TREINTA'
            }
            if (n + '' == '31') {
                return 'TREINTA Y UNO'
            }
            if (n + '' == '32') {
                return 'TREINTA Y DOS'
            }
            if (n + '' == '33') {
                return 'TREINTA Y TRES'
            }
            if (n + '' == '34') {
                return 'TREINTA Y CUATRO'
            }
            if (n + '' == '35') {
                return 'TREINTA Y CINCO'
            }
            if (n + '' == '36') {
                return 'TREINTA Y SEIS'
            }
            if (n + '' == '37') {
                return 'TREINTA Y SIETE'
            }
            if (n + '' == '38') {
                return 'TREINTA Y OCHO'
            }
            if (n + '' == '39') {
                return 'TREINTA Y NUEVE'
            }
            if (n + '' == '40') {
                return 'CUARENTA'
            }
            if (n + '' == '41') {
                return 'CUARENTA Y UNO'
            }
            if (n + '' == '42') {
                return 'CUARENTA Y DOS'
            }
            if (n + '' == '43') {
                return 'CUARENTA Y TRES'
            }
            if (n + '' == '44') {
                return 'CUARENTA Y CUATRO'
            }
            if (n + '' == '45') {
                return 'CUARENTA Y CINCO'
            }
            if (n + '' == '46') {
                return 'CUARENTA Y SEIS'
            }
            if (n + '' == '47') {
                return 'CUARENTA Y SIETE'
            }
            if (n + '' == '48') {
                return 'CUARENTA Y OCHO'
            }
            if (n + '' == '49') {
                return 'CUARENTA Y NUEVE'
            }
            if (n + '' == '50') {
                return 'CINCUENTA'
            }
            if (n + '' == '51') {
                return 'CINCUENTA Y UNO'
            }
            if (n + '' == '52') {
                return 'CINCUENTA Y DOS'
            }
            if (n + '' == '53') {
                return 'CINCUENTA Y TRES'
            }
            if (n + '' == '54') {
                return 'CINCUENTA Y CUATRO'
            }
            if (n + '' == '55') {
                return 'CINCUENTA Y CINCO'
            }
            if (n + '' == '56') {
                return 'CINCUENTA Y SEIS'
            }
            if (n + '' == '57') {
                return 'CINCUENTA Y SIETE'
            }
            if (n + '' == '58') {
                return 'CINCUENTA Y OCHO'
            }
            if (n + '' == '59') {
                return 'CINCUENTA Y NUEVE'
            }
            if (n + '' == '60') {
                return 'SESENTA'
            }
            if (n + '' == '61') {
                return 'SESENTA Y UNO'
            }
            if (n + '' == '62') {
                return 'SESENTA Y DOS'
            }
            if (n + '' == '63') {
                return 'SESENTA Y TRES'
            }
            if (n + '' == '64') {
                return 'SESENTA Y CUATRO'
            }
            if (n + '' == '65') {
                return 'SESENTA Y CINCO'
            }
            if (n + '' == '66') {
                return 'SESENTA Y SEIS'
            }
            if (n + '' == '67') {
                return 'SESENTA Y SIETE'
            }
            if (n + '' == '68') {
                return 'SESENTA Y OCHO'
            }
            if (n + '' == '69') {
                return 'SESENTA Y NUEVE'
            }
            if (n + '' == '70') {
                return 'SETENTA'
            }
            if (n + '' == '71') {
                return 'SETENTA Y UNO'
            }
            if (n + '' == '72') {
                return 'SETENTA Y DOS'
            }
            if (n + '' == '73') {
                return 'SETENTA Y TRES'
            }
            if (n + '' == '74') {
                return 'SETENTA Y CUATRO'
            }
            if (n + '' == '75') {
                return 'SETENTA Y CINCO'
            }
            if (n + '' == '76') {
                return 'SETENTA Y SEIS'
            }
            if (n + '' == '77') {
                return 'SETENTA Y SIETE'
            }
            if (n + '' == '78') {
                return 'SETENTA Y OCHO'
            }
            if (n + '' == '79') {
                return 'SETENTA Y NUEVE'
            }
            if (n + '' == '80') {
                return 'OCHENTA'
            }

            return ''
        },

        numerosAMeses(n){
            if (n + '' == '1') {
                return 'ENERO'
            }
            if (n + '' == '2') {
                return 'FEBRERO'
            }
            if (n + '' == '3') {
                return 'MARZO'
            }
            if (n + '' == '4') {
                return 'ABRIL'
            }
            if (n + '' == '5') {
                return 'MAYO'
            }
            if (n + '' == '6') {
                return 'JUNIO'
            }
            if (n + '' == '7') {
                return 'JULIO'
            }
            if (n + '' == '8') {
                return 'AGOSTO'
            }
            if (n + '' == '9') {
                return 'SEPTIEMBRE'
            }
            if (n + '' == '11') {
                return 'NOVIEMBRE'
            }
            if (n + '' == '12') {
                return 'DICIEMBRE'
            }

            return ''
        },

        numeroADias(n){
            if (n + '' == '1') {
                return 'LUNES'
            }
            if (n + '' == '2') {
                return 'MARTES'
            }
            if (n + '' == '3') {
                return 'MIERCOLES'
            }
            if (n + '' == '4') {
                return 'JUEVES'
            }
            if (n + '' == '5') {
                return 'VIERNES'
            }
            if (n + '' == '6') {
                return 'SABADO'
            }
            if (n + '' == '7') {
                return 'DOMINGO'
            }

            return ''
        }
    }
}
</script>
