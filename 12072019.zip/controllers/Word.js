const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarNotaria = require('../middlewares/VerificarNotaria');

var createReport = require('docx-templates');

module.exports = (app,Documento,User) => {

    app.get('/word/:id', verificarToken(User),verificarNotaria(User),(req,res) => {
        Documento.findById(req.params.id,function(err,doc){
            if (err)
                res.send(err);

            if (doc) {
                doc.otorgante = doc.otorgantes[0];
                doc.favorecido = doc.favorecidos[0];
                
                createReport({
                    template: 'documentos/templates/'+doc.notaria+'/'+doc.template+'.docx',
                    output: 'public/reports/'+doc.notaria+'/'+doc.tramite+'-'+doc.factura+'.docx',
                    data: {
                        documento: doc,
                    },
                });

                res.json(doc);
            }else{
                res.json({
                    msg_servidor: 'Ese documento no Existe.'
                });
            }
        });
    });

}