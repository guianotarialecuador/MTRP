module.exports = User => {
    return (req,res,next) => {
        User.findOne({user: req.header("user") , token: req.header("token"), notaria: req.header("notaria")},function(err, usuario) {
            if (err)
                res.send(err);
            if (usuario) {
                next();
            }else{
                res.json({
                    msg_servidor: 'No estas autorizado.'
                });
            }
        });
    }
}