<template>
    <div class="row">
        <div class="form-group col-4">
            Tratamiento:
            <select v-model="menorForm.tratamiento" class="form-control">
                <option>Hijo</option>
                <option>Hija</option>
                <option>Niño</option>
                <option>Niña</option>
            </select>
        </div>
        <div class="form-group col-4">
            Cedula
            <input v-model="menorForm.cedula" type="text" class="form-control">
        </div>
        <div class="form-group col-4">
            Pasaporte
            <input v-model="menorForm.pasaporte" type="text" class="form-control">
        </div>
        <div class="form-group col-12">
            Nombres
            <input v-model="menorForm.nombre" type="text" class="form-control">
        </div>
        
        <div class="form-group col-4">
            Edad
            <input v-model="menorForm.edad" type="text" class="form-control">
        </div>
        <div class="form-group col-4">
            Fecha de Salida
            <input v-model="menorForm.fecha_salida" type="date" class="form-control">
        </div>
        <div class="form-group col-4">
            Fecha de Retorno
            <input v-model="menorForm.fecha_retorno" type="date" class="form-control">
        </div>
        <div class="form-group col-12">
            Domicilio
            <input v-model="menorForm.direccion" type="text" class="form-control">
        </div>
        <div class="form-group col-4">
            Pais de Destino
            <input v-model="menorForm.pais_desino" type="text" class="form-control">
        </div>
        <div class="form-group col-4">
            Nacionalidad
            <input v-model="menorForm.nacionalidad" type="text" class="form-control">
        </div>
        <div class="form-group col-4">
            Aerolinea
            <input v-model="menorForm.aerolinea" type="text" class="form-control">
        </div>
        
        <div class="form-group col-12">
            Motivo de Viaje
            <input v-model="menorForm.motivo_viaje" type="text" class="form-control">
        </div>
        <div class="form-group col-6">
            Nombre de Tutor
            <input v-model="menorForm.tutor" type="text" class="form-control">
        </div>
        <div class="form-group col-6">
            Domicilio del Tutor
            <input v-model="menorForm.tutor_direccion" type="text" class="form-control">
        </div>
        <div class="form-group col-6">
            Telefono del Tutor
            <input v-model="menorForm.tutor_telefono" type="text" class="form-control">
        </div>
        <div class="form-group col-6">
            Correo electronico del Tutor
            <input v-model="menorForm.tutor_email" type="text" class="form-control">
        </div>
        <div class="col-12">
            <b-btn @click="enviar">Enviar</b-btn>
        </div>
    </div>
</template>
<script>
export default {
    name: 'menorx',
    props: ['miusuario','persona'],
    data(){
        return {
            menorForm: {
                tratamiento: '',///
                nombre:'',///
                edad: '',///
                direccion: '',///
                fecha_salida: '',///
                fecha_retorno: '',////
                pais_desino: '',///
                tutor: '',///
                aerolinea: '',///
                tutor_direccion: '',//
                tutor_telefono: '',///
                tutor_email: '',//
                motivo_viaje: '',///
                cedula: '',///
                pasaporte:'',//
                idioma: 'ESPAÑOL',
                nacionalidad: 'ECUATORIANA',///
                edad_l: '',
                cedula_l: '',

                acompanante_nombre: '',
                acompanante_relacion: '',
                acompanante_cedula: '',
                acompanante_direccion: '',
                acompanante_telefono: '',
                acompanante_email: '',
            }
        }
    },
    mounted(){
        if (this.persona) {
            this.menorForm = this.persona;
        }       
    },
    methods: {
        enviar(){
            this.$emit('nuevoMenor',this.menorForm);

            this.menorForm = {
                tratamiento: '',///
                nombre:'',///
                edad: '',///
                direccion: '',///
                fecha_salida: '',///
                fecha_retorno: '',////
                pais_desino: '',///
                tutor: '',///
                aerolinea: '',///
                tutor_direccion: '',//
                tutor_telefono: '',///
                tutor_email: '',//
                motivo_viaje: '',///
                cedula: '',///
                pasaporte:'',//
                idioma: 'ESPAÑOL',
                nacionalidad: 'ECUATORIANA',///

                edad_l: '',
                cedula_l: '',

                acompanante_nombre: '',
                acompanante_relacion: '',
                acompanante_cedula: '',
                acompanante_direccion: '',
                acompanante_telefono: '',
                acompanante_email: '',
            };
        },
    }
}
</script>
