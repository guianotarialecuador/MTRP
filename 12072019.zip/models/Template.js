module.exports = mongoose => {
    let esquema = new mongoose.Schema({
        nombre: String,
        notaria: String,
    });

    return mongoose.model('Templates',esquema);
}