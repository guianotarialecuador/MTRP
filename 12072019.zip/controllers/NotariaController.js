const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarAdministrador = require('../middlewares/SuperUsuario');//Verifica que sea el super Usuario
const fs = require('fs');

module.exports = (app,User,Notaria) => {
    
    app.get('/api/notarias', verificarToken(User),verificarAdministrador(User),(req,res) => {
        Notaria.find({},function(err,notarias){
            if (err)
                res.send(err);

            res.json(notarias);
        });
    });

    app.delete('/api/notarias/:id',verificarToken(User),verificarAdministrador(User),(req,res)=>{
        Notaria.findById(req.params.id,function(err,notaria) {
            if (err)
                res.send(err);
            
            if (notaria) {
                Notaria.findByIdAndDelete(req.params.id,function(e){
                    if (e)
                        res.send(e);
                    res.json({
                        msg_servidor_success: 'Notaria Eliminada.'
                    });
                });         
            }else{
                res.json({
                    msg_servidor: 'Esa Notaria no Existe.'
                });
            }

        });
    });

    app.post('/api/notarias',verificarToken(User),verificarAdministrador(User),(req,res) => {
        Notaria.findOne({nombre: req.body.nombre},function(err, notaria) {
            if (err)
                res.send(err);
               
            if(notaria){
                res.json({
                    msg_servidor: 'Ese nombre de Notaria ya esta en uso.'
                });
            }else{
                var directorio = './documentos/templates/' + req.body.nombre;
                var directorio2 = './public/reports/' + req.body.nombre;

                if (!fs.existsSync(directorio)) {
                    fs.mkdirSync(directorio);
                }
                
                if (!fs.existsSync(directorio2)) {
                    fs.mkdirSync(directorio2);
                }

                Notaria.create({
                    nombre: req.body.nombre,
                },function(e,notaria2){
                    if (e) {
                        res.send(e);
                    }
                    res.json(notaria2);
                });
            }
        });
    });
    
}