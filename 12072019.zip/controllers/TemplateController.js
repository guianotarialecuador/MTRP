const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarNotaria = require('../middlewares/VerificarNotaria');

module.exports = (app,User,Template) => {
    
    app.get('/api/templates', verificarToken(User),verificarNotaria(User),(req,res) => {
        Template.find({notaria: req.header("notaria")},function(err,templates){
            if (err)
                res.send(err);

            res.json(templates);
        });
    });

    app.post('/api/templates',verificarToken(User),verificarNotaria(User),(req,res) => {
        Template.create({
            nombre: req.body.nombre,
            notaria: req.header("notaria"),
        },function(e,template){
            if (e) {
                res.send(e);
            }
            res.json(template);
        });
    });

    app.put('/api/templates/:id',verificarToken(User),verificarNotaria(User),(req,res) => {

        Template.findById(req.params.id,function(err,template) {
            if (err)
                res.send(err);
            
            if (template) {
                if (req.body.nombre) {
                    template.nombre = req.body.nombre;
                }

                template.save((e)=>{
                    if (e)
                        res.send(e);
                    res.json(template);
                })
            }else{
                res.json({
                    msg_servidor: 'Ese template no Existe.'
                });
            }

        });

    });
    
}