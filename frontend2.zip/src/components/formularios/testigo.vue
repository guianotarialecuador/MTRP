<template>
    <form @submit.prevent="guardar" class="row mx-1">
        <div class="form-group col-md-6">
            Tratamiento
            <select class="form-control" v-model="testigoForm.tratamiento">
                <option v-for="(p,index) in prefijos" :key="index">
                    {{ p }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-6">
            Titulo
            <select class="form-control" v-model="testigoForm.titulo">
                <option v-for="(t,index) in titulos" :key="index">
                    {{ t }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-4">
            Documento
            <select class="form-control" v-model="testigoForm.documento_tipo">
                <option v-for="(d,index) in documentos" :key="index">
                    {{ d }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-4">
            Nro.
            
            <!-- espacio provicional -->
            <span v-if="testigoForm.documento == '1723413504' && testigoForm.documento_tipo == 'cédula de ciudadanía'" class="text-danger">*INSOLVENTE</span>
            <!-- espacio provicional -->
            <input type="text" @keyup="verificarCiudadano" class="form-control" placeholder="Nro de Documento" v-model="testigoForm.documento">
        </div>
        <div class="form-group col-md-4">
            Certificado de Votacion
            <input type="text" class="form-control" placeholder="Certificado de Votacion" v-model="testigoForm.votacion">
        </div>

        <div class="form-group col-12">
            Nombres
            <input type="text" class="form-control" placeholder="Nombres" v-model="testigoForm.nombre">
        </div>

        <div class="form-group col-md-6">
            Estado Civil
            <select class="form-control" v-model="testigoForm.estado_civil">
                <option v-for="(e,index) in estados" :key="index">
                    {{ e }}
                </option>
            </select>
        </div>
        <div class="form-group col-md-6">
            Nacionalidad
            <input type="text" class="form-control" placeholder="Nacionalidad" v-model="testigoForm.nacionalidad">
        </div>
        <hr class="col-10">

        <div class="form-group col-10">
            Ocupación
            <select v-model="testigoForm.ocupacion" class="form-control">
                <option v-for="(o,index) in ocupaciones" :key="index">
                    <span v-if="testigoForm.tratamiento == 'SEÑOR'">
                        {{ o.masculino }}
                    </span>
                    <span v-else>
                        {{ o.femenino }}
                    </span>
                </option>
            </select>
        </div>
        <div class="col-2">
            <b-btn @click="showModal1" variant="success rounded-circle" v-b-tooltip.hover title="Añadir Ocupacion" class="mt-4">
                +
            </b-btn>
        </div>
        <hr class="col-10">
        
        <div class="form-group col-12">
            Domicilio
            <input type="text" class="form-control" placeholder="Domicilio" v-model="testigoForm.direccion">
        </div>

        <div class="form-group col-md-4">
            Teléfono
            <input type="text" class="form-control" placeholder="Teléfono" v-model="testigoForm.telefono">
        </div>
        <div class="form-group col-md-4">
            Celular
            <input type="text" class="form-control" placeholder="Celular" v-model="testigoForm.celular">
        </div>
        <div class="form-group col-md-4">
            Correo Electrónico
            <input type="text" class="form-control" placeholder="Correo Electronico" v-model="testigoForm.email">
        </div>
        <div class="col-12">
            <b-btn v-if="!testigoactual" type="submit" variant="primary">
                Guardar
            </b-btn>
            <b-btn v-else @click="editar" variant="primary">
                Guardar
            </b-btn>
        </div>
        
        <b-modal class="border-dark" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" ref="modOct1" hide-footer title="Añadir Ocupación/Profesión">
            <ocupacion :miusuario="miusuario" @nuevaOcupacion="hideModal1"></ocupacion>
        </b-modal>
    </form>
</template>
<script>
import axios from 'axios'

import ocupacion from './ocupacion'

export default {
    name: 'testigo',
    props: ['testigoactual','tipo','miusuario'],
    components: {
        ocupacion
    },
    data(){
        return {
            prefijos: [
                'SEÑOR',
                'SEÑORA'
            ],
            titulos: [
                'ABOGADO',
                'INGENIERO',
                'DOCTOR',
                'LICENCIADO',
                'ECONOMISTA'
            ],
            documentos: [
                'cédula de ciudadanía',
                'pasaporte'
            ],
            estados: [
                'soltero',
                'divorciado',
                'casado',
                'viudo'
            ],
            ocupaciones: [],

            testigoForm: {
                tipo: '',
                genero: 'M',
                tratamiento: '',
                titulo: '',
                documento: '',
                documento_tipo: '',
                votacion: '',
                nombre: '',
                estado_civil: '',
                nacionalidad: '',
                ocupacion: '',
                direccion: '',
                telefono: '',
                celular: '',
                email: '',
            }
        }
    },
    mounted(){
        this.cargarOcupaciones();

        if (this.tipo) {
            this.testigoForm.tipo = this.tipo;
        }else{
            this.testigoForm.tipo = 'NATURAL';
        }
        if (this.persona) {
            this.testigoForm = this.persona
        }
    },
    methods: {
        verificarCiudadano(){
            //provicional
            if (this.testigoForm.documento == '1723413504' && this.testigoForm.documento_tipo == 'cédula de ciudadanía') {
                this.testigoForm.nombre = 'JOSE FRANCISCO CRUZ CORRO';
                this.testigoForm.tratamiento = 'SEÑOR';
                this.testigoForm.titulo = 'INGENIERO';
                this.testigoForm.estado_civil = 'soltero';
                this.testigoForm.nacionalidad = 'ECUATORIANO';
                this.testigoForm.ocupacion = 'OCUPACIÓN Programador';
                this.testigoForm.direccion = 'QUITO';
                this.testigoForm.telefono = '02555666';
                this.testigoForm.celular = '0999555666';
                this.testigoForm.email = 'miemail@gmail.com';
            }
            //fin provicional
        },
        cargarOcupaciones(){
            axios.get('/api/ocupaciones',{headers:{user:this.miusuario.user,token:this.miusuario.token}}).then((res)=>{
                this.ocupaciones = res.data;
            }).catch((e)=>{
                if (e) {
                    throw e;
                }
            });
        },
        showModal1(){
            this.$refs.modOct1.show();
        },
        hideModal1(){
            this.$refs.modOct1.hide();
        },
        editar(){
            this.$emit('testigoE',this.testigoForm);
        },
        guardar(){
            this.$emit('testigoN',this.testigoForm);
            this.testigoForm = {
                tipo: '',
                genero: 'M',
                tratamiento: '',
                titulo: '',
                documento: '',
                documento_tipo: '',
                votacion: '',
                nombre: '',
                estado_civil: '',
                nacionalidad: '',
                ocupacion: '',
                direccion: '',
                telefono: '',
                celular: '',
                email: '',
            };
        }
    }
}
</script>
