<template>
    <div class="row">
         
    </div>
</template>
<script>
import axios from 'axios';

export default {
    name: "testigo",
    props: ['miusuario','tipo','persona'],
    data(){
        return {
            insolvente: '',

            comparecienteForm: {
                
            }
        }
    }
}
</script>
