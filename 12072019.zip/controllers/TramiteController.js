const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarNotaria = require('../middlewares/VerificarNotaria');

module.exports = (app,User,Tramite) => {
    
    app.get('/api/tramites', verificarToken(User),verificarNotaria(User),(req,res) => {
        Tramite.find({notaria: req.header("notaria")},function(err,tramites){
            if (err)
                res.send(err);

            res.json(tramites);
        });
    });

    app.post('/api/tramites',verificarToken(User),verificarNotaria(User),(req,res) => {
        Tramite.create({
            nombre: req.body.nombre,
            notaria: req.header("notaria"),
            template: req.body.template,

            persona_natural: req.body.persona_natural,
            persona_juridica: req.body.persona_juridica,
            menor: req.body.menor,
            minuta: req.body.minuta,
            declaracion: req.body.declaracion,
            manejo_capital: req.body.manejo_capital,
        },function(e,tramite){
            if (e) {
                res.send(e);
            }
            res.json(tramite);
        });
    });

    app.put('/api/tramites/:id',verificarToken(User),verificarNotaria(User),(req,res) => {

        Tramite.findById(req.params.id,function(err,tramite) {
            if (err)
                res.send(err);
            
            if (tramite) {
                if (req.body.nombre) {
                    tramite.nombre = req.body.nombre;
                }
                if (req.body.template) {
                    tramite.template = req.body.template;
                }
                
                if (req.body.persona_natural) {
                    tramite.persona_natural = req.body.persona_natural;
                }
                if (req.body.persona_juridica) {
                    tramite.persona_juridica = req.body.persona_juridica;
                }
                if (req.body.menor) {
                    tramite.menor = req.body.menor;
                }
                if (req.body.minuta) {
                    tramite.minuta = req.body.minuta;
                }
                if (req.body.declaracion) {
                    tramite.declaracion = req.body.declaracion;
                }
                if (req.body.manejo_capital) {
                    tramite.manejo_capital = req.body.manejo_capital;
                }

                tramite.save((e)=>{
                    if (e)
                        res.send(e);
                    res.json(tramite);
                })
            }else{
                res.json({
                    msg_servidor: 'Ese tramite no Existe.'
                });
            }

        });

    });
    
}