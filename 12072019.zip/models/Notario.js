module.exports = mongoose => {
    let esquema = new mongoose.Schema({
        nombre: String,
        notaria: String,
        genero: String,
        leyenda: String,
        firma: String
    });

    return mongoose.model('Notarios',esquema);
}