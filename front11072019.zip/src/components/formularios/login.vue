<template>
    <form class="row mx-1" @submit.prevent="login">
        <div class="form-group col-12 pt-2">
            Usuario
            <input type="text" v-model="user.user" required class="form-control">
        </div>

        <div class="form-group col-12">
            Clave
            <input type="password" v-model="user.password" required class="form-control">
        </div>

        <div class="col-12">
            <b-alert v-if="invalidado" show dismissible variant="danger">
                {{invalidado}}
            </b-alert>
        </div>
            
        <div class="col-12 py-2">
            <b-btn type="submit" variant="primary">
                Entrar
            </b-btn>
        </div>
    </form>
</template>
<script>

import axios from 'axios'

export default {
    name: "login",
    data(){
        return {
            invalidado: '',
            user: {
                user: '',
                password: ''
            }
        }
    },
    methods: {
        login(){
            axios.post('/api/login',this.user).then((res) => {
                if (res.data.msg_servidor) {
                    this.invalidado = res.data.msg_servidor;
                }else{
                    this.invalidado = '';
                    this.$emit('logueago',res.data);
                }
            }).catch((error) => {
                if (error) {
                    throw error;                    
                }
                this.invalidado = 'Error Interno, Intente Mas tarde.';
            });
        }
    }
}
</script>
