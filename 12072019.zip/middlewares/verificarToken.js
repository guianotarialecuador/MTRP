module.exports = User => {
    return (req,res,next) => {
        User.findOne({user: req.header("user") , token: req.header("token")},function(err, usuario) {
            if (err)
                res.send(err);
            if (usuario) {
                if (usuario.activado == 'Activo' || usuario.rol == 'Super Usuario') {
                    next();                    
                } else {
                    res.json({
                        msg_servidor: 'Su Usuario esta desactivado.'
                    });    
                }
            }else{
                res.json({
                    msg_servidor: 'No estas autorizado.'
                });
            }
        });
    }
}