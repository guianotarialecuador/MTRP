<template>
    <div class="row">
        <div class="form-group col-6">
            Tratamiento:
            <select v-model="comparecienteForm.tratamiento_juridico" class="form-control" v-if="comparecienteForm.tipo == 'JURIDICO'">
                <option>EL</option>
                <option>LA</option>
            </select>
            <select v-model="comparecienteForm.tratamiento" class="form-control" v-else>
                <option>EL SEÑOR</option>
                <option>LA SEÑORA</option>
                <option>LA SEÑORITA</option>
            </select>
        </div>
        <div class="form-group col-6" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Titulo
            <select v-model="comparecienteForm.titulo" class="form-control">
                <option>ABOGADO</option>
                <option>ABOGADA</option>
                <option>INGENIERO</option>
                <option>INGENIERA</option>
                <option>DOCTOR</option>
                <option>DOCTORA</option>
                <option>LICENCIADO</option>
                <option>LICENCIADA</option>
            </select>
        </div>
        <hr class="col-10">
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Cedula
            <input v-model="comparecienteForm.cedula" type="text" class="form-control" @keyup="autollenadoCedula();">
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Papeleta de Votacion
            <input v-model="comparecienteForm.votacion" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Pasaporte
            <input v-model="comparecienteForm.pasaporte" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo == 'JURIDICO'">
            RUC
            <input v-model="comparecienteForm.ruc" type="text" class="form-control">
        </div>
        
        <div class="form-group col-12" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Nombres
            <span v-if="insolvente != ''" class="text-danger">
                INSOLVENTE
            </span>
            <input v-model="comparecienteForm.nombre" type="text" @keyup="nombreInsolvente(comparecienteForm.nombre)" class="form-control">
        </div>
        <div class="form-group col-12" v-if="comparecienteForm.tipo == 'JURIDICO'">
            Razon Social
            <span v-if="insolvente != ''" class="text-danger">
                INSOLVENTE
            </span>
            <input v-model="comparecienteForm.razon_social" type="text" @keyup="nombreInsolvente(comparecienteForm.razon_social)" class="form-control">
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Estado Civil
            <select v-model="comparecienteForm.estado_civil" class="form-control">
                <option>SOLTERO</option>
                <option>SOLTERA</option>
                <option>CASADO</option>
                <option>CASADA</option>
                <option>DIVORCIADO</option>
                <option>DIVORCIADA</option>
                <option>UNION LIBRE</option>
            </select>
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Edad
            <input v-model="comparecienteForm.edad" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4" v-if="comparecienteForm.tipo != 'JURIDICO'">
            Ocupacion
            <input v-model="comparecienteForm.ocupacion" type="text" class="form-control">
        </div>
        <hr class="col-10">
        
        <div class="form-group col-12">
            Domicilio
            <input v-model="comparecienteForm.direccion" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4">
            Tipo
            <select v-model="comparecienteForm.tipo_otorgante" class="form-control">
                <option>QUE OTORGA</option>
                <option>A FAVOR DE</option>
            </select>
        </div>
        <div class="form-group col-md-4">
            Telefono
            <input v-model="comparecienteForm.telefono" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4">
            Correo Electronico
            <input v-model="comparecienteForm.email" type="text" class="form-control">
        </div>

        <hr class="col-10">
        <div class="form-group col-12">
            Declaracion
            <textarea v-model="comparecienteForm.declaracion" rows="4" class="form-control"></textarea>
        </div>
        <div class="form-group col-md-4">
            Calidad
            <select v-model="comparecienteForm.calidad" class="form-control">
                <option>por sus propios derechos</option>
                <option>Apoderado</option>
                <option>Presidente</option>
                <option>Representante Legal</option>
                <option>COMPRADOR</option>
                <option>VENDEDOR</option>
            </select>
        </div>
        <div class="form-group col-md-8" v-if="comparecienteForm.tipo == 'JURIDICO'">
            Representante <strong>{{comparecienteForm.nombre}}</strong>
            <br>
            <b-btn @click="showModal1" variant="primary">
                Editar
            </b-btn>
        </div>
        <div class="form-group col-md-4">
            Idioma
            <input v-model="comparecienteForm.idioma" type="text" class="form-control">
        </div>
        <div class="form-group col-md-4">
            Nacionalidad
            <input v-model="comparecienteForm.nacionalidad" type="text" class="form-control">
        </div>
        <div class="col-12">
            <b-btn @click="enviar" variant="primary">
                Guardar
            </b-btn>
        </div>

        <b-modal ref="repreMod1" hide-footer :title="'Persona' + tipo">
            <div class="row">
                <div class="form-group col-6">
                    Tratamiento:
                    <select v-model="comparecienteForm.tratamiento">
                        <option>EL SEÑOR</option>
                        <option>LA SEÑORA</option>
                        <option>LA SEÑORITA</option>
                    </select>
                </div>
                <div class="form-group col-6">
                    Titulo
                    <select v-model="comparecienteForm.titulo" class="form-control">
                        <option>ABOGADO</option>
                        <option>ABOGADA</option>
                        <option>INGENIERO</option>
                        <option>INGENIERA</option>
                        <option>DOCTOR</option>
                        <option>DOCTORA</option>
                        <option>LICENCIADO</option>
                        <option>LICENCIADA</option>
                    </select>
                </div>
                <div class="form-group col-12">
                    Nombres 
                    <span v-if="insolvente != ''" class="text-danger">
                        INSOLVENTE
                    </span>
                    <input v-model="comparecienteForm.nombre" type="text" class="form-control" @keyup="nombreInsolvente(comparecienteForm.nombre)">
                </div>
                
                <div class="form-group col-md-4">
                    Cedula
                    <input v-model="comparecienteForm.cedula" type="text" class="form-control" @keyup="autollenadoCedula();">
                </div>
                <div class="form-group col-md-4">
                    Papeleta de Votacion
                    <input v-model="comparecienteForm.votacion" type="text" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    Pasaporte
                    <input v-model="comparecienteForm.pasaporte" type="text" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    Estado Civil
                    <select v-model="comparecienteForm.estado_civil" class="form-control">
                        <option>SOLTERO</option>
                        <option>SOLTERA</option>
                        <option>CASADO</option>
                        <option>CASADA</option>
                        <option>DIVORCIADO</option>
                        <option>DIVORCIADA</option>
                        <option>UNION LIBRE</option>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    Ocupacion
                    <input v-model="comparecienteForm.ocupacion" type="text" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    Edad
                    <input v-model="comparecienteForm.edad" type="text" class="form-control">
                </div>
            </div>
        </b-modal>
    </div>
</template>
<script>
import axios from 'axios';

export default {
    name: 'compareciente',
    props: ['miusuario','tipo','persona'],
    data(){
        return {
            insolvente: '',

            comparecienteForm: {
                tipo: '',///
                nombre:'',///
                edad: '',///
                direccion: '',///
                calidad: '',///
                telefono: '',///
                email: '',///
                tratamiento: '',///
                declaracion: '',///
                testigos: [],
                representados: [],
                puede_firmar: '',
                cedula: '',///
                pasaporte:'',///
                estado_civil: '',///
                ocupacion: '',///
                conyuge: null,
                ruc: '',///
                razon_social: '',////
                direccion_empresarial: '',
                idioma: 'ESPAÑOL',///
                nacionalidad: 'ECUATORIANA',///
                titulo: '',///
                votacion: '',///
                tipo_otorgante: 'QUE OTORGA',///

                tratamiento_juridico: '',///
                
                edad_l: '',
                cedula_l: '',
            }
        }
    },
    mounted(){
        if (this.persona) {
            this.comparecienteForm = this.persona;
        }else{
            this.comparecienteForm.tipo = this.tipo;
        }        
    },
    methods: {
        autollenadoCedula(){
            if (this.comparecienteForm.cedula == '1723413504') {
                this.comparecienteForm.edad = '25';
                this.comparecienteForm.nombre = 'JOSE FRANCO CRUZ CORRO';
                this.comparecienteForm.direccion = 'Av. Mariscal Sucre OE-23 y Michelena, canton Quito';
                this.comparecienteForm.telefono = '02 544 6754';
                this.comparecienteForm.email = 'cruz@gmail.com';   
                this.comparecienteForm.ocupacion = 'Programador';   
                this.comparecienteForm.estado_civil = 'SOLTERO';  
                
                this.insolvente = 'INSOLVENTE';     
            }
            this.cedulaInsolvente(this.comparecienteForm.cedula);
        },
        nombreInsolvente(n){
            if (n.split(' ').length == 4) {
                axios.get('/api/insolventes-nombre/'+n,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    if (res.data.length > 0) {
                        this.insolvente = 'INSOLVENTE';
                    }else{
                        this.insolvente = '';
                    }
                }).catch((e)=>{
                    console.log(e);
                });                
            }
        },
        cedulaInsolvente(n){
            if (n.split(' ').length == 4) {
                axios.get('/api/insolventes-cedula/'+n,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    if (res.data.length > 0) {
                        this.insolvente = 'INSOLVENTE';
                    }else{
                        this.insolvente = '';
                    }
                }).catch((e)=>{
                    console.log(e);
                });                
            }
        },

        showModal1(){
            this.$refs.repreMod1.show();
        },
        hideModal1(){
            this.$refs.repreMod1.hide();
        },
        enviar(){
            this.$emit('nuevoCompareciente',this.comparecienteForm);
            

            this.comparecienteForm = {
                tipo: '',///
                nombre:'',///
                edad: '',///
                direccion: '',///
                calidad: '',///
                telefono: '',///
                email: '',///
                tratamiento: '',///
                declaracion: '',///
                testigos: [],
                representados: [],
                puede_firmar: '',
                cedula: '',///
                pasaporte:'',///
                estado_civil: '',///
                ocupacion: '',///
                conyuge: null,
                ruc: '',///
                razon_social: '',////
                direccion_empresarial: '',
                idioma: 'ESPAÑOL',///
                nacionalidad: 'ECUATORIANA',///
                titulo: '',///
                votacion: '',///
                tipo_otorgante: 'QUE OTORGA',///

                tratamiento_juridico: '',///
            }
        }
    }
}
</script>
