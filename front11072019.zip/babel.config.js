module.exports = {
  presets: [
    '@vue/app'
  ]
}
