<template>
    <div class="container border-dark">
        <div role="tablist">

            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-1 variant="primary">Notarias</b-button>
                </b-card-header>
                <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <ul>
                            <li v-for="(nota,index) in notarias" :key="index">
                                {{nota.nombre}}
                            </li>
                        </ul>
                        <b-btn @click="showModal2" variant="primary">Crear notaria</b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>
            
            <b-card no-body class="mb-1">
                <b-card-header header-tag="header" class="p-1" role="tab">
                    <b-button block href="#" v-b-toggle.accordion-2 variant="primary">Usuarios</b-button>
                </b-card-header>
                <b-collapse id="accordion-2" accordion="my-accordion" role="tabpanel">
                    <b-card-body>
                        <div class="row">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table border">
                                        <thead class="bg-secondary text-white">
                                            <tr>
                                                <th>
                                                    Email
                                                </th>
                                                <th>
                                                    Nombre
                                                </th>
                                                <th>
                                                    Usuario
                                                </th>
                                                <th>
                                                    Notaria
                                                </th>
                                                <th>
                                                    Estado
                                                </th>
                                                <th>
                                                    
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(usuario,index) in usuarios" :key="index">
                                                <td>
                                                    {{usuario.email}}
                                                </td>
                                                <td>
                                                    {{usuario.name}}
                                                </td>
                                                <td>
                                                    {{usuario.user}}
                                                </td>
                                                <td>
                                                    {{usuario.notaria}}
                                                </td>
                                                <td>
                                                    <span v-if="usuario.activado == 'Activo'" class="text-success">
                                                        Activo
                                                    </span>
                                                    <span v-else class="text-danger">
                                                        Desactivado
                                                    </span>
                                                </td>
                                                <td>
                                                    <b-btn @click="activarUsuario(index)" v-if="usuario.activado == 'Activo'" class="m-1" variant="danger">
                                                        Desactivar
                                                    </b-btn>
                                                    <b-btn @click="activarUsuario(index)" v-else class="m-1" variant="success">
                                                        Activar
                                                    </b-btn>
                                                    <b-btn @click="showModal3(index)" class="m-1" variant="primary">
                                                        Editar
                                                    </b-btn>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <b-btn @click="showModal1" variant="primary">Crear Usuario</b-btn>
                    </b-card-body>
                </b-collapse>
            </b-card>

        </div>

        <b-modal ref="newNotaMod" hide-footer title="Agregar Notaria" header-bg-variant="primary" body-bg-variant="secondary">
            <form class="row" @submit.prevent="crearNotaria">
                <div class="form-group col-12">
                    Nombre
                    <input type="text" v-model="notariaN.nombre" class="form-control" placeholder="Nombre">
                    <b-alert v-if="errorN" show dismissible variant="danger">
                        {{ errorN }}
                    </b-alert>
                </div>
                <div class="col-12">
                    <b-btn type="submit" variant="primary">Crear</b-btn>
                </div>
            </form>
        </b-modal>
        <b-modal ref="newUserMod1" hide-footer title="Agregar Usuario" header-bg-variant="primary" body-bg-variant="secondary">
            <form class="row" @submit.prevent="crearUsuario">
                <div class="form-group col-md-6">
                    Usuario
                    <input required type="text" v-model="usuarioN.user" class="form-control" placeholder="Usuario">
                    <b-alert v-if="errorU" show dismissible variant="danger">
                        {{ errorU }}
                    </b-alert>
                </div>
                <div class="form-group col-md-6">
                    Clave
                    <input required type="password" v-model="usuarioN.password" class="form-control" placeholder="Clave">
                </div>
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" v-model="usuarioN.name" class="form-control" placeholder="Nombre">
                </div>
                <div class="form-group col-md-6">
                    Email
                    <input type="text" v-model="usuarioN.email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group col-12">
                    Notaria
                    <select v-model="usuarioN.notaria" class="form-control">
                        <option v-for="(nota,index) in notarias" :key="index">
                            {{nota.nombre}}
                        </option>
                    </select>
                </div>
                <div class="col-12">
                    <b-btn type="submit" variant="primary">Crear</b-btn>
                </div>
            </form>
        </b-modal>
        <b-modal ref="newUserMod3" hide-footer title="Editar Usuario" header-bg-variant="primary" body-bg-variant="secondary">
            <form v-if="editaU" class="row" @submit.prevent="editarUsuario">
                <div class="form-group col-md-6">
                    Usuario
                    <input disabled type="text" v-model="editaU.user" class="form-control" placeholder="Usuario">
                </div>
                <div class="form-group col-md-6">
                    Clave
                    <input type="password" v-model="editaU.password" class="form-control" placeholder="Llenar solo si quiere Cambiar Clave">
                </div>
                <div class="form-group col-md-6">
                    Nombre
                    <input type="text" v-model="editaU.name" class="form-control" placeholder="Nombre">
                </div>
                <div class="form-group col-md-6">
                    Email
                    <input type="text" v-model="editaU.email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group col-12">
                    Notaria
                    <select v-model="editaU.notaria" class="form-control">
                        <option v-for="(nota,index) in notarias" :key="index">
                            {{nota.nombre}}
                        </option>
                    </select>
                </div>
                <div class="col-12">
                    <b-btn type="submit" variant="primary">Crear</b-btn>
                </div>
            </form>
        </b-modal>
    </div>
</template>
<script>
import axios from 'axios'

export default {
    name: 'administrador',
    props: ['miusuario'],
    data(){
        return {
            errorU: '',
            errorN: '',

            editaU: null,

            usuarios: [],
            notarias: [],

            notariaN:{
                nombre: ''
            },
            usuarioN:{
                email: '',
                name: '',
                user: '',
                password: '',
                rol: '',
                notaria: ''
            },
        }
    },
    mounted(){
        this.getUsuarios();
        this.getNotarias();
    },
    methods: {
        showModal1(){
            this.$refs.newUserMod1.show();
        },
        hideModal1(){
            this.$refs.newUserMod1.hide();
        },
        showModal3(index){
            this.editaU = this.usuarios[index];
            this.$refs.newUserMod3.show();
        },
        hideModal3(){
            this.editaU = null;
            this.$refs.newUserMod3.hide();
        },
        showModal2(){
            this.$refs.newNotaMod.show();
        },
        hideModal2(){
            this.$refs.newNotaMod.hide();
        },
        getNotarias(){
            axios.get('/api/notarias',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.notarias = res.data;
            }).catch((e)=>{
                console.log(e);
            })
        },
        getUsuarios(){
            axios.get('/api/users',{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                this.usuarios = res.data;
            }).catch((e)=>{
                console.log(e);
            })
        },
        crearNotaria(){
            axios.post('/api/notarias',this.notariaN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                if (res.data.msg_servidor) {
                    this.errorN = res.data.msg_servidor;
                } else {
                    this.notarias.push(res.data);
                    this.notariaN={
                        nombre: '',
                    };     
                    this.errorN = '';
                    this.hideModal2();               
                }
            }).catch((e)=>{
                console.log(e);
            });
        },
        editarUsuario(){
            axios.put('/api/users/'+this.editaU._id,this.editaU,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                if (res.data.msg_servidor) {
                    this.errorU = res.data.msg_servidor;
                } else {
                    this.errorU = '';
                    this.hideModal3();               
                }
            }).catch((e)=>{
                console.log(e);
            });
        },
        crearUsuario(){
            axios.post('/api/users',this.usuarioN,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                if (res.data.msg_servidor) {
                    this.errorU = res.data.msg_servidor;
                } else {
                    this.usuarios.push(res.data);
                    this.usuarioN={
                        email: '',
                        name: '',
                        user: '',
                        password: '',
                        rol: '',
                        notaria: ''
                    };     
                    this.errorU = '';
                    this.hideModal1();               
                }
            }).catch((e)=>{
                console.log(e);
            });
        },
        activarUsuario(index){
            if (this.usuarios[index].activado == 'Activo') {
                let dato = {
                    activado: 'Inactivo'
                }
                axios.put('/api/users/'+this.usuarios[index]._id,dato,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    this.getUsuarios();
                }).catch((e)=>{
                    console.log(e);
                });
            }else{
                let dato = {
                    activado: 'Activo'
                }
                axios.put('/api/users/'+this.usuarios[index]._id,dato,{headers:{user:this.miusuario.user,token:this.miusuario.token,notaria:this.miusuario.notaria}}).then((res)=>{
                    this.getUsuarios();
                }).catch((e)=>{
                    console.log(e);
                });
            }
        }
    }
}
</script>
