<template>
  <div id="app">

      <b-navbar toggleable="lg" class="mb-0 fondoBaner" type="dark" sticky>

        <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

        <b-navbar-brand href="#">
          <h3 class="text-white">
            MATRIZADOR PERFECTO NOTARIAL
          </h3>
        </b-navbar-brand>

        <b-collapse id="nav-collapse" is-nav>
          
          <b-navbar-nav v-if="user">
            <b-nav-item href="#" v-for="(m,index) in menu" :key="index" @click="seleccionarMenu(m)">
              {{ m }}
            </b-nav-item>

            <b-nav-item href="#" @click="ulogin">
              Cerrar Sesion
            </b-nav-item>
          </b-navbar-nav>

          <b-navbar-nav class="mx-auto">

          </b-navbar-nav>
        </b-collapse>

        <b-navbar-brand href="#">
          <img src="~@/assets/logoGuia.png" width="150" height="150" alt="">
        </b-navbar-brand>
      </b-navbar>

      <div v-if="!user">
        
        <div class=" p-4 my-2 mx-1 shadow">
          <center>
            <h1>
              <strong  style="font-size:50px;">
                MATRIZADOR PERFECTO NOTARIAL. &copy; 2019.
              </strong>
            </h1>
            <br>
              <h2>LE PROVEE DE PAZ MENTAL AL NOTARIO.</h2>
          </center>

          <br>
          <hr>
          <br>

          <div class="row">
            <div class="col-md-6 px-2 border-right">
              <div class="card border-dark w-75">
                <div class="card-header bg-primary">
                  <strong>
                    Iniciar Sesión
                  </strong>
                </div>
                <div class="card-body bg-secondary">
                  <login @logueago="login">
                  </login>
                </div>
              </div>
            </div>

            <div class="col-md-6 p-2">
              <div class="mx-4 py-4">
                <h2>
                  <strong>
                    Beneficios para la Notaria:
                  </strong>
                </h2>
                <br>
                <ul>
                  <li>
                    Permite la administración de los documentos notariales, a los cuales podrá, crear, 
                    modificar y eliminar.
                  </li>
                  <li>
                    Permite la generación de documentos en formato Word, dichos documentos son generados 
                    de acuerdo con el formato de la notaria, como tipo de letra, márgenes, logo de la 
                    Notaria.
                  </li>
                  <li>
                    Ayuda a validar documentos de sus clientes (Cédula, ruc, pasaporte).
                  </li>
                  <li>
                    El Sistema extraerá de agencias gubernamentales y automáticamente mostrará 
                    el perfil y datos de ciudadanía, 
                    los datos que se requiere para generar el 
                    documento notarial.
                  </li>
                  <li>
                    Permitirá localizar cualquier documento notarial que se haya creado en meses o años 
                    anteriores.
                  </li>
                </ul>
                
                <br>
                <h2>
                  <strong>
                    Beneficios para el Usuario:
                  </strong>
                </h2>
                <br>
                <ul>
                  <li>
                    Seguridad en la creación de la escritura notarial o modelo perteneciente al ciudadano(Usuario).
                  </li>
                  <li>
                    El notario podrá monitorizar el desarrollo dentro de su notaría desde cualquier parte del mundo, 
                    sabrá que Matrizador creó el documento y toda información relacionada con el mismo.
                  </li>
                  <li>
                    Nunca más existirá un error dentro de la estructura literaria del modelo creado.
                  </li>
                </ul>
              </div>
            </div>
          </div>


        </div>

        <div class="w-100 p-4 fondoBaner text-white">
          <div class="row">
            <strong class="col-4">
              &copy; Directorio Fotográfico Notarial del Ecuador. 2019
            </strong>
            <div class="col-5">
              <a target="_blank" class="text-white" href="https://www.facebook.com/profile.php?id=100022300877553">
                  <img src="~@/assets/facebook.png" height="40" alt="Facebook">
                  <br>
                  Guía Notarial Ec-Home
              </a>
              <span>
                | guianotarialecuador@outlook.com
              </span>
            </div>
            <div class="col-3 text-right">
              <a target="_blank" href="http://www.funcionjudicial.gob.ec/">
                <img src="~@/assets/logocj.png" height="60" alt="Funcion Judicial">
              </a>
            </div>
          </div>
        </div>

      </div>

      <div v-else class="fullHeight fondoPlomo">
        
        <div class="fullHeight fondoPlomo">
          <nuevo-documento :miusuario="user" @documentoE="docEditado" :docactual="docActual" @documentoN="menuSelect = 'Documentos';" v-if="menuSelect == 'Nuevo'" class="my-2 shadow bg-light"></nuevo-documento>
          <documentos :miusuario="user" @documentoE="editarDoc" v-if="menuSelect == 'Documentos'" class="my-2 shadow bg-light"></documentos>
          <consultas v-if="menuSelect == 'Consultas'"></consultas>
        </div>

        <div class="w-100 p-4 fondoBaner text-white">
          <div class="row">
            <strong class="col-4">
              &copy; Directorio Fotográfico Notarial del Ecuador. 2019
            </strong>
            <div class="col-5">
              <a target="_blank" class="text-white" href="https://www.facebook.com/profile.php?id=100022300877553">
                  <img src="~@/assets/facebook.png" height="40" alt="Facebook">
                  <br>
                  Guía Notarial Ec-Home
              </a>
              <span>
                | guianotarialecuador@outlook.com
              </span>
            </div>
            <div class="col-3 text-right">
              <a target="_blank" href="http://www.funcionjudicial.gob.ec/">
                <img src="~@/assets/logocj.png" height="60" alt="Funcion Judicial">
              </a>
            </div>
          </div>
        </div>
      </div>

  </div>
</template>

<script>
  import login from './components/formularios/login'
  import NuevoDocumento from './components/NuevoDocumento'
  import Documentos from './components/Documentos'
  import Consultas from './components/Consultas'

  export default {
    name: 'matrizadorperfectonotarial',
    data(){
      return {
        editandoDoc: false,
        docActual: null,
        user: null,

        menuSelect: '',
        menu: [
          'Documentos',
          'Nuevo',
          'Consultas'
        ],
      }
    },
    components: {
      login,
      NuevoDocumento,
      Documentos,
      Consultas
    },
    methods: {
      docEditado(){
        this.menuSelect = 'Documentos';
        this.editandoDoc = false;
        this.docActual = null;
      },
      editarDoc(doc){
        this.docActual = doc;
        this.editandoDoc = true;
        this.menuSelect = 'Nuevo'
      },
      seleccionarMenu(m){
        this.menuSelect = m;
        if(m == "Nuevo"){
          this.editandoDoc = false;
          this.docActual = null;
        }
      },
      login(u){
        this.user = u;
      },
      ulogin(){
        this.user = null;
      }
    }
  }
</script>

<style>
  html, body{
    height: 100vh;
  }

  .fullHeight {
    min-height: 75vh;
  }

  .contenidoNoSesion {
    height: 100vh;
    background-image: url('~@/assets/fondoNotaria.jpg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
    background-position: center;
  }

  .vidrio-fondo {
    background-color: rgba(100, 100, 255, .5)
  }

  .azulObscuro{
    background-color: navy;
  }

  .fondoPlomo{
    background-color: slategrey;
  }

  .fondoBaner {
    background: rgba(179,220,237,1);
    background: -moz-linear-gradient(left, rgba(179,220,237,1) 0%, rgba(20,35,94,1) 0%, rgba(23,150,209,1) 100%);
    background: -webkit-gradient(left top, right top, color-stop(0%, rgba(179,220,237,1)), color-stop(0%, rgba(20,35,94,1)), color-stop(100%, rgba(23,150,209,1)));
    background: -webkit-linear-gradient(left, rgba(179,220,237,1) 0%, rgba(20,35,94,1) 0%, rgba(23,150,209,1) 100%);
    background: -o-linear-gradient(left, rgba(179,220,237,1) 0%, rgba(20,35,94,1) 0%, rgba(23,150,209,1) 100%);
    background: -ms-linear-gradient(left, rgba(179,220,237,1) 0%, rgba(20,35,94,1) 0%, rgba(23,150,209,1) 100%);
    background: linear-gradient(to right, rgba(179,220,237,1) 0%, rgba(20,35,94,1) 0%, rgba(23,150,209,1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3dced', endColorstr='#1796d1', GradientType=1 );
  }

</style>
