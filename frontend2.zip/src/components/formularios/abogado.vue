<template>
    <form class="row mx-1" @submit.prevent="guardar">
        <div class="form-group col-12">
            Título:
            <select v-model="abogadoFrom.titulo" class="form-control">
                <option v-for="(t,index) in titulos" :key="index">
                    {{ t }}
                </option>
            </select>
        </div>
        <div class="form-group col-12">
            Nombres:
            <input type="text" class="form-control" v-model="abogadoFrom.nombre">
        </div>
        <div class="form-group col-12">
            Calidad:
            <input type="text" class="form-control" v-model="abogadoFrom.calidad">
        </div>
        <div class="form-group col-12">
            # Matrícula:
            <input type="text" class="form-control" v-model="abogadoFrom.matricula">
        </div>
        <div class="form-group col-12">
            Pertenece a:
            <select v-model="abogadoFrom.pertenece" class="form-control">
                <option v-for="(lugar,index) in lugares" :key="index">
                    {{ lugar }}
                </option>
            </select>
        </div>
        <div class="col-12">
            <b-btn v-if="!abogadoactual" type="submit" variant="primary">
                Guardar
            </b-btn>
            <b-btn v-else @click="editar" variant="primary">
                Guardar
            </b-btn>
        </div>
    </form>
</template>
<script>
import axios from 'axios'

export default {
    name: 'abogado',
    props: ['abogadoactual','miusuario'],
    data(){
        return {
            titulos: [
                'Doctor',
                'Doctora',
                'Abogado',
                'Abogada',
                'Señor',
                'Señora',
            ],
            lugares: [
                'Colegio de Abogados de Pichincha',
                'Colegio de Abogados de Guayas',
                'Colegio de Abogados de Manabí',
                'Colegio de Abogados de Azuay',
                'Colegio de Abogados de Bolivar',
                'Colegio de Abogados de Cañar',
                'Colegio de Abogados de Carchi',
                'Colegio de Abogados de Cotopaxi',
                'Colegio de Abogados de Chimborazo',
                'Colegio de Abogados de El Oro',
                'Colegio de Abogados de Esmeraldas',
                'Colegio de Abogados de Imbabura',
                'Colegio de Abogados de Loja',
                'Colegio de Abogados de Los Ríos',
                'Colegio de Abogados de Napo',
                'Colegio de Abogados de Orellana',
                'Colegio de Abogados de Paztaza',
                'Colegio de Abogados de Sucumbios',
                'Colegio de Abogados de Santa Elena',
                'Colegio de Abogados de Tungurahua'
            ],

            abogadoFrom: {
                titulo: '',
                nombre: '',
                calidad: '',
                matricula: '',
                pertenece: ''
            }
        }
    },
    methods: {
        guardar(){
            axios.post('/api/abogados',this.abogadoFrom,{headers:{user:this.miusuario.user,token:this.miusuario.token}}).then((res) => {
                this.$emit('abogadoN',this.abogadoFrom);
            }).catch((e) => {
                throw e;
            });
        }
    }
}
</script>
