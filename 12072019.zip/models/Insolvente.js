module.exports = mongoose => {
    let esquema = new mongoose.Schema({
        nombre: String,
        cedula: String,
        causa: String,
        status: String,
        actor: String,
    });

    return mongoose.model('Insolventes',esquema);
}