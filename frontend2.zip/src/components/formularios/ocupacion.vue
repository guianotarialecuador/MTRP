<template>
    <form @submit.prevent="guardar" class="row mx-1">
        <div class="form-group col-12">
            Tipo
            <select class="form-control" v-model="ocupacionForm.tipo">
                <option value="ocupación">
                    OCUPACIÓN
                </option>
                <option value="profesión">
                    PROFESIÓN
                </option>
            </select>
        </div>
        <div class="form-group col-12">
            Término Masculino
            <input type="text" class="form-control" v-model="ocupacionForm.masculino">
        </div>
        <div class="form-group col-12">
            Término Femenino
            <input type="text" class="form-control" v-model="ocupacionForm.femenino">
        </div>
        <div class="col-12">
            <b-btn type="submit" variant="primary">
                Guardar
            </b-btn>
        </div>
    </form>
</template>
<script>
import axios from 'axios'

export default {
    name: 'ocupacion',
    props: ['miusuario'],
    data(){
        return {
            ocupacionForm: {
                tipo: 'ocupación',
                femenino: '',
                masculino: ''
            }
        }
    },
    methods: {
        guardar(){
            axios.post('/api/ocupaciones',this.ocupacionForm,{headers:{user:this.miusuario.user,token:this.miusuario.token}}).then((res)=>{
                this.$emit('nuevaOcupacion',res.data);
            }).catch((e)=>{
                if (e) {
                    throw e;
                }
            });
        }
    }
}
</script>
