const md5 = require('md5');
const verificarToken = require('../middlewares/verificarToken');//Verifica que sea un usuario autentico
const verificarAdministrador = require('../middlewares/SuperUsuario');//Verifica que sea el super Usuario

module.exports = (app,User) => {
    
    app.get('/api/users', verificarToken(User),verificarAdministrador(User),(req,res) => {
        User.find({},"_id user email name rol notaria activado",function(err,usuarios){
            if (err)
                res.send(err);

            res.json(usuarios);
        });
    });
    
    app.put('/api/users/:id',verificarToken(User),verificarAdministrador(User),(req,res)=>{
        User.findById(req.params.id,"_id user email name rol notaria activado",function(err,usuario) {
            if (err)
                res.send(err);
            
            if (usuario) {
                if (req.body.email) {
                    usuario.email = req.body.email;
                }
                if (req.body.activado) {
                    usuario.activado = req.body.activado;
                }
                if (req.body.name) {
                    usuario.name = req.body.name;
                }
                if (req.body.password) {
                    usuario.password = md5(req.body.password);
                }
                if (req.body.rol && usuario.rol != "Super Usuario" && req.body.rol != "Super Usuario") {
                    usuario.rol = req.body.rol;
                }
                if (req.body.notaria) {
                    usuario.notaria = req.body.notaria;
                }       
                usuario.save((e)=>{
                    if (e)
                        res.send(e);
                    res.json(usuario);
                })
            }else{
                res.json({
                    msg_servidor: 'Ese Usuario no Existe.'
                });
            }

        });
    });    

    app.delete('/api/users/:id',verificarToken(User),verificarAdministrador(User),(req,res)=>{
        User.findById(req.params.id,function(err,usuario) {
            if (err)
                res.send(err);
            
            if (usuario) {
                if (usuario.rol == "Super Usuario") {
                    res.json({
                        msg_servidor: 'Ese Usuario no puede ser Eliminado.'
                    });
                }else{
                    User.findByIdAndDelete(req.params.id,function(e){
                        if (e)
                            res.send(e);
                        res.json({
                            msg_servidor_success: 'Usuario Eliminado.'
                        });
                    });  
                }                
            }else{
                res.json({
                    msg_servidor: 'Ese Usuario no Existe.'
                });
            }

        });
    });

    app.post('/api/users',verificarToken(User),verificarAdministrador(User),(req,res) => {
        let fecha = new Date(); 

        let newToken = fecha.getTime()+"";

        User.findOne({user: req.body.user},function(err, usuario) {
            if (err)
                res.send(err);
               
            if(usuario){
                res.json({
                    msg_servidor: 'Ese nombre de Usuario ya esta en uso.'
                });
            }else{
                if (req.body.rol == "Super Usuario") {
                    res.json({
                        msg_servidor: 'Ese rol no puede ser Ocupado por nadie mas.'
                    });
                }else{
                    User.create({
                        email: req.body.email,
                        name: req.body.name,
                        activado: 'Activo',
                        user: req.body.user,
                        password: md5(req.body.password),
                        token: newToken,
                        rol: '',
                        notaria: req.body.notaria
                    },function(e,usuario2){
                        if (e) {
                            res.send(e);
                        }
                        res.json({
                            _id: usuario2._id,
                            email: req.body.email,
                            name: req.body.name,
                            user: req.body.user,
                            rol: '',
                            notaria: req.body.notaria,
                            activado: 'Activo',
                        });
                    });
                }
            }
        });
    });

    app.post('/api/login',(req,res) => {
        let fecha = new Date(); 

        let newToken = fecha.getTime()+"";

        User.findOneAndUpdate({user: req.body.user, password: md5(req.body.password)},{token: newToken},function(err, usuario) {
            if (err)
                res.send(err);
               
            if(usuario){
                if (usuario.activado != 'Activo' && usuario.rol != 'Super Usuario') {
                    res.json({
                        msg_servidor: 'Su Usuario a sido desactivado.'
                    });
                }else{
                    res.json({
                        user: usuario.user,
                        token: newToken,
                        notaria: usuario.notaria,
                        rol: usuario.rol,
                        name: usuario.name,
                    });
                }
            }else{
                res.json({
                    msg_servidor: 'Usuario o Clave Incorrectos.'
                });
            }
        });
    });

    app.post('/api/perfil',verificarToken(User),(req,res)=>{
        User.findOne({user: req.header("user") , token: req.header("token")},"_id user email name rol notaria",function(err,usuario) {
            if (err)
                res.send(err);
            
            if (usuario) {
                if (req.body.email) {
                    usuario.email = req.body.email;
                }
                if (req.body.name) {
                    usuario.name = req.body.name;
                }
                if (req.body.password) {
                    usuario.password = md5(req.body.password);
                }
                usuario.save((e)=>{
                    if (e)
                        res.send(e);
                    res.json(usuario);
                })
            }else{
                res.json({
                    msg_servidor: 'Ese Usuario no Existe.'
                });
            }

        });
    });

}