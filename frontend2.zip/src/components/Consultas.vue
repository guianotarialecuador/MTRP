<template>
    <div class="container bg-info py-2">
        <h1>
            Consultas
        </h1>
        <hr>
        <ul>
            <li v-for="(consulta,index) in consultasFrame" :key="index">
                <b-btn variant="link" @click="showModal(index)" class="text-white">
                    {{ consulta.name }}
                </b-btn>
            </li>
        </ul>
        <b-modal ref="modConsulta" title="Consulta" hide-footer size="xl">
            <b-embed
                v-if="consultaactual"
                type="iframe"
                aspect="4by3"
                :src="consultaactual.url"
                allowfullscreen
            ></b-embed>
        </b-modal>
    </div>
</template>
<script>
export default {
    name: 'consultas',
    data(){
        return {
            consultaactual: null,
            consultasFrame: [
                {
                    name: 'FORMULARIO ÚNICO PARA PETICIÓN DE TERMINACIÓN DE LA UNIÓN DE HECHO POR MUTUO ACUERDO',
                    url: 'http://www.funcionjudicial.gob.ec/www/pdf/FORMULARIO%20UNICO%20PARA%20PETICION%20DE%20TERMINACION%20DE%20LA%20UNION%20DE%20HECHO%20POR%20MUTUO%20ACUERDO.PDF'
                },
                {
                    name: 'FORMULARIO ÚNICO PARA PETICIÓN DE DIVORCIO POR MUTUO CONSENTIMIENTO',
                    url: 'http://www.funcionjudicial.gob.ec/www/pdf/FORMULARIO%20UNICO%20PARA%20PETICION%20DE%20DIVORCIO%20POR%20MUTUO%20CONSENTIMIENTO.PDF'
                },
                {
                    name: 'FORMULARIO ÚNICO DE SOLICITUD DE NUEVO DÍA Y HORA PARA AUDIENCIA DE CONCILIACIÓN EN EL TRÁMITE DE DIVORCIO POR MUTUO CONSENTIMIENTO',
                    url: 'http://www.funcionjudicial.gob.ec/www/pdf/FORMULARIO%20UNICO%20DE%20SOLICITUD%20%20DE%20NUEVO%20DIA%20Y%20HORA%20PARA%20AUDIENCIA%20DE%20CONCILIACION%20EN%20EL%20TRAMITE%20DE%20%20DIVORCIO%20POR%20MUTUO%20CONSENTIMIENTO.PDF'
                },
                {
                    name: 'FORMULARIO ÚNICO DE SOLICITUD DE NUEVO DÍA Y HORA PARA AUDIENCIA DE CONCILIACIÓN EN EL TRÁMITE DE TERMINACIÓN DE LA UNIÓN DE HECHO POR MUTUO ACUERDO',
                    url: 'http://www.funcionjudicial.gob.ec/www/pdf/FORMULARIO%20UNICO%20DE%20SOLICITUD%20DE%20NUEVO%20D%C3%8DA%20Y%20HORA%20PARA%20AUDIENCIA%20DE%20CONCILIACION%20EN%20EL%20TRAMITE%20DE%20TERMINACION%20DE%20LA%20UNION%20DE%20HECHO%20POR%20MUTUO.PDF'
                },

                {
                    name: 'Verificación de Actos Notariales',
                    url: 'https://notarias.funcionjudicial.gob.ec/notarial/public/verificacionActo.jsf'
                },

                {
                    name: 'Codigo Postal',
                    url: 'http://www.codigopostal.gob.ec/'
                },

                {
                    name: 'Directorio Notarial',
                    url: 'http://www.funcionjudicial.gob.ec/index.php/es/component/content/article/507.html'
                },

                {
                    name: 'Documentos Extraviados',
                    url: 'https://appsj.funcionjudicial.gob.ec/documentosExtraviados/publico/formulario.jsf'
                },

                {
                    name: '',
                    url: ''
                }
            ]
        }
    },
    methods: {
        showModal(index){
            this.$refs.modConsulta.show();
            this.consultaactual = this.consultasFrame[index];
        },
        hideModal(){
            this.$refs.modConsulta.hide();
        }
    }
}
</script>
<style>
    .fullSize {
        width: 100%;
        height: absolute;
    }
</style>
