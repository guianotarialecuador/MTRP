<template>
    <div class="container border-dark">
        <div class="row bg-primary text-white">
            <div class="form-group col-md-2">
                Tipo
                <select class="form-control p-1 my-0" v-model="documento.tramite">
                    <option value="-Ninguno-">-Ninguno-</option>
                    <option v-for="(tramite,index) in tramites" :key="index" :value="tramite.nombre">
                        {{ tramite.nombre }}
                    </option>
                </select>
            </div>
            <div class="form-group col-md-2">
                Plantilla
                <select class="form-control p-1 my-0" v-model="documento.plantilla">
                    <option value="-Ninguno-">-Ninguno-</option>
                    <option v-for="(plantilla,index) in plantillas" :key="index" :value="plantilla.nombre">
                        {{ plantilla.nombre }}
                    </option>
                </select>
            </div>
            <div class="form-group col-md-2">
                Referencia
                <input type="text" v-model="documento.referencia" class="form-control p-1 my-0" placeholder="-Ninguno-">
            </div>
            <div class="form-group col-md-2">
                No. Factura
                <input type="text" v-model="documento.factura" class="form-control p-1 my-0" placeholder="-Ninguno-">
            </div>
            <div class="form-group col-md-2">
                No. Trámite
                <input type="text" v-model="documento.tramite_numero" class="form-control p-1 my-0" placeholder="-Ninguno-">
            </div>
            <div class="form-group col-md-2">
                No. Copias
                <input type="text" v-model="documento.copias" class="form-control p-1 my-0" placeholder="-Ninguno-">
            </div>
        </div>
        <div class="row">
            <div class="col-12 bg-primary py-2 border-top">
                <button type="button" class="btn btn-outline-light" @click="showModal1">
                    + Agregar Persona Natural
                </button>
            </div>
            <div class="col-12 py-2">
                <div class="responsive-table">
                    <table class="table border">
                        <thead class="headerX py-0">
                            <tr class="py-0">
                                <th class="border py-0">
                                    Persona
                                </th>
                                <th class="border py-0">
                                    Documento
                                </th>
                                <th class="border py-0">
                                    Nombres
                                </th>
                                <th class="border py-0">
                                    Estado Civil
                                </th>
                                <th class="border py-0">
                                    Profesión/Ocupacion
                                </th>
                                <th class="border py-0">
                                    Nacionalidad
                                </th>
                                <th class="border py-0">
                                    Forma de Compadecer
                                </th>
                                <th class="border py-0">
                                    Accion
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(persona,index) in documento.personas" :key="index" class="py-0">
                                <td  class="border py-0">
                                    {{ persona.tipo }}
                                </td>
                                <td  class="border py-0">
                                    <span v-if="persona.documento_tipo == 'cédula de ciudadanía'">
                                        C.C.
                                    </span>
                                    <span v-else>
                                        Pasaporte
                                    </span>
                                    - {{ persona.documento }}
                                </td>
                                <td  class="border py-0">
                                    {{ persona.nombre }}
                                </td>
                                <td  class="border py-0">
                                    {{ persona.estado_civil }}
                                </td>
                                <td  class="border py-0">
                                    {{ persona.ocupacion }}
                                </td>
                                <td  class="border py-0">
                                    {{ persona.nacionalidad }}
                                </td>
                                <td  class="border py-0">
                                    {{ persona.forma_compadecer }}
                                </td>
                                <td  class="border py-0">
                                    <b-btn variant="primary" class="m-1" @click="showModal2(index)">
                                        Editar
                                    </b-btn>
                                    <b-btn variant="danger" class="m-1" @click="borrar(index)">
                                        Eliminar
                                    </b-btn>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div v-if="documento.plantilla.indexOf('CM') != -1" class="form-group col-12">
                Minuta
                <textarea class="form-control textareafont" v-model="documento.minuta" rows="10"></textarea>
            </div>
            <div v-if="documento.plantilla.indexOf('CM') != -1" class="form-group col-10">
                Minuta Firmada Por:
                <select class="form-control" v-model="documento.abogado">
                    <option v-for="(ab,index) in abogados" :key="index" :value="ab">
                        {{ ab.nombre + ', ' + ab.calidad + '. Mat. ' + ab.matricula }}
                    </option>
                </select>
            </div>
            <div v-if="documento.plantilla.indexOf('CM') != -1" class="form-group col-2">
                <b-btn @click="showModal3" variant="primary rounded-circle" v-b-tooltip.hover title="Añadir Abogado" class="mt-4">
                    +
                </b-btn>
            </div>
            <div class="form-group col-12">
                Segundo-Objeto-Declaro
                <textarea class="form-control textareafont" v-model="documento.declaracion" rows="3"></textarea>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12 py-2">
                <b-btn @click="guardar" v-if="documento.plantilla && documento.tramite && documento.plantilla != '-Ninguno-' && documento.tramite != '-Ninguno-' && documento.declaracion && documento.personas.length > 0 && (documento.plantilla.indexOf('CM') == -1 || (documento.minuta && documento.abogado))" variant="primary">Guardar</b-btn>
                <b-btn v-else disabled>Guardar</b-btn>
            </div>
        </div>

        <b-modal class="border-dark" ref="docModal1" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" hide-footer title="Agregar Persona Natural" size="lg">
            <compadeciente :miusuario="miusuario" @personaN="agregarPersona">

            </compadeciente>
        </b-modal>
        <b-modal class="border-dark" ref="docModal2" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" hide-footer title="Editar Persona" size="lg">
            <compadeciente :miusuario="miusuario" @personaE="editarPersona" :persona="personaEdit">

            </compadeciente>
        </b-modal>
        <b-modal class="border-dark" ref="docModal3" scrollable body-bg-variant="secondary" header-border-variant="dark" centered header-bg-variant="primary" hide-footer title="Agregar Abogado">
            <abogado :miusuario="miusuario" @abogadoN="agregarAbogado">

            </abogado>
        </b-modal>
    </div>
</template>
<script>
import axios from 'axios'
import moment from 'moment'

import compadeciente from './formularios/compadeciente'
import abogado from './formularios/abogado'

export default {
    name: 'nuevo-documento',
    props: ['docactual','miusuario'],
    components: {
        compadeciente,
        abogado
    },
    data(){
        return {
            header1: {
                user: this.miusuario.user,
                token: this.miusuario.token
            },
            header2: {
                user: this.miusuario.user,
                token: this.miusuario.token,
                notaria: this.miusuario.notaria
            },

            tramites: [],
            plantillas: [],
            condiciones: [],

            personaEdit: null,
            personaIndex: -1,

            abogados: [],

            documento: {
                notaria: this.miusuario.notaria,
                personas: [],
                plantilla: '-Ninguno-',
                tramite: '-Ninguno-',
                minuta: '',
                referencia: '',
                factura: '',
                tramite: '',
                copias: '',
                declaracion: '',
                fichero: '',
                template: '',
                abogado: null,
                creador: '',
                usuario_cambio: '',
                fecha: '',
                fecha_creacion: '',
                fecha_cambio: '',
                hora_creacion: '',
                hora_cambio: '',
            }
        }
    },
    mounted(){
        moment.locale('es');
        
        if (this.docactual) {
            this.documento = this.docactual;
        }
        
        this.header1.user = this.miusuario.user;
        this.header1.token = this.miusuario.token;

        this.header2.user = this.miusuario.user;
        this.header2.token = this.miusuario.token;
        this.header2.notaria = this.miusuario.notaria;

        this.getAbogados();
        this.getTramites();
        this.getPlantillas();
        this.getCondiciones();
    },
    methods: {
        getAbogados(){
            axios.get('/api/abogados',{headers:this.header1}).then((res)=>{
                this.abogados = res.data;
            }).catch((e) => {
                if(e)
                    throw e;
            });
        },
        getTramites(){
            axios.get('/api/tramites',{headers:this.header2}).then((res)=>{
                this.tramites = res.data;
            }).catch((e) => {
                if(e)
                    throw e;
            });
        },
        getPlantillas(){
            axios.get('/api/plantillas',{headers:this.header2}).then((res)=>{
                this.plantillas = res.data;
            }).catch((e) => {
                if(e)
                    throw e;
            });
        },
        getCondiciones(){
            axios.get('/api/condiciones',{headers:this.header2}).then((res)=>{
                this.condiciones = res.data;
            }).catch((e) => {
                if(e)
                    throw e;
            });
        },
        /////////////
        guardar(){
            if (!this.docactual) {
                for (let i = 0; i < this.condiciones.length; i++) {
                    if(this.condiciones[i].tramite == this.documento.tramite && this.condiciones[i].plantilla == this.documento.plantilla){
                        this.documento.template = this.condiciones[i].template;
                        break;
                    }
                }

                this.documento.creador = this.miusuario.name;
                
                let fecha =  new Date();

                this.documento.fecha_creacion = fecha.getFullYear() + '-' + (fecha.getMonth()+1) + '-' + fecha.getDate();
                this.documento.hora_creacion = fecha.getHours() + ':' + fecha.getMinutes();

                this.documento.fecha = moment().format('LLLL');

                ///PRUEBAS EN LA MAQUINA
                axios.post('/api/documentos',this.documento,{headers:this.header2}).then((res) => {
                    this.documento = res.data;
                    this.$emit('documentoN');
                }).catch((e) => {
                    if (e) {
                        throw e;
                    }
                });    
                //FIN     
            }else{
                for (let i = 0; i < this.condiciones.length; i++) {
                    if(this.condiciones[i].tramite == this.documento.tramite && this.condiciones[i].plantilla == this.documento.plantilla){
                        this.documento.template = this.condiciones[i].template;
                        break;
                    }
                }
                
                this.documento.usuario_cambio = this.miusuario.name;

                let fecha =  new Date();

                this.documento.fecha_cambio = fecha.getFullYear() + '-' + (fecha.getMonth()+1) + '-' + fecha.getDate();
                this.documento.hora_cambio = fecha.getHours() + ':' + fecha.getMinutes();
                
                this.documento.fecha = moment().format('LLLL');
                
                ///PRUEBAS EN LA MAQUINA
                axios.put('/api/documentos/' + this.documento._id,this.documento,{headers:this.header2}).then((res) => {
                    this.documento = res.data;
                    this.$emit('documentoE');
                }).catch((e) => {
                    if (e) {
                        throw e;
                    }
                });    
                //FIN
            }
            this.documento = {
                notaria: this.miusuario.notaria,
                personas: [],
                plantilla: '-Ninguno-',
                tramite: '-Ninguno-',
                minuta: '',
                referencia: '',
                factura: '',
                tramite: '',
                copias: '',
                declaracion: '',
                fichero: '',
                template: '',
                abogado: null,
                creador: '',
                usuario_cambio: '',
                fecha: '',
                fecha_creacion: '',
                fecha_cambio: '',
                hora_creacion: '',
                hora_cambio: '',
            };  
        },
        borrar(index){
            this.documento.personas.splice(index,1);
        },
        agregarPersona(persona){
            this.documento.personas.push(persona);
            this.hideModal1();
        },
        agregarAbogado(ab){
            this.documento.abogado = ab;
            this.hideModal3();
        },
        editarPersona(persona){
            this.documento.personas[this.personaIndex] = persona;
            this.hideModal2();
        },
        showModal1(){
            this.$refs.docModal1.show();
        },
        hideModal1(){
            this.$refs.docModal1.hide();
        },
        showModal2(index){
            this.personaEdit = this.documento.personas[index];
            this.documento.personaIndex = index;
            this.$refs.docModal2.show();
        },
        hideModal2(){
            this.$refs.docModal2.hide();
            this.personaEdit = null;
            this.documento.personaIndex = -1;
        },
        showModal3(){
            this.$refs.docModal3.show();
        },
        hideModal3(){
            this.$refs.docModal3.hide();
        },
    }
}
</script>

<style>

 .fondo1 {
     background-color: cadetblue;
 }

.headerX {
background: rgba(242,246,248,1);
background: -moz-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(242,246,248,1)), color-stop(16%, rgba(216,225,231,1)), color-stop(51%, rgba(181,198,208,1)), color-stop(100%, rgba(224,239,249,1)));
background: -webkit-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -o-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: -ms-linear-gradient(top, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
background: linear-gradient(to bottom, rgba(242,246,248,1) 0%, rgba(216,225,231,1) 16%, rgba(181,198,208,1) 51%, rgba(224,239,249,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f2f6f8', endColorstr='#e0eff9', GradientType=0 ); 
}

.textareafont {
    font-size: 10px;
}

</style>
