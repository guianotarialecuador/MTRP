module.exports = mongoose => {
    let esquema = new mongoose.Schema({
        nombre: String,
    });

    return mongoose.model('Notarias',esquema);
}